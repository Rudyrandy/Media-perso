document.addEventListener('DOMContentLoaded', () => {
    const chatContainer = document.getElementById('chat-container');
    const userInput = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const messageTemplate = document.getElementById('message-template');

    // Identifiant unique pour le patient (pourrait être dynamique)
    const patientID = "andy_permanent_user";
    const webhookUrl = "https://supreme-giggle-7vjqwgrq74gr2xrw5-5678.app.github.dev/webhook/ia/chat";

    function createMessageElement(content, isUser = false) {
        const clone = messageTemplate.content.cloneNode(true);
        const messageDiv = clone.querySelector('.message');
        const contentDiv = clone.querySelector('.message-content');

        messageDiv.classList.add(isUser ? 'user' : 'bot');
        contentDiv.textContent = content; // textContent handles raw string safely

        return clone;
    }

    function appendMessage(content, isUser = false) {
        // Enlever le message de bienvenue s'il existe
        const welcome = document.querySelector('.welcome-message');
        if (welcome) welcome.remove();

        const messageEl = createMessageElement(content, isUser);
        chatContainer.appendChild(messageEl);
        chatContainer.scrollTop = chatContainer.scrollHeight;
    }

    function showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'typing-indicator';
        indicator.id = 'typing-indicator';
        indicator.innerHTML = '<div class="dot"></div><div class="dot"></div><div class="dot"></div>';
        chatContainer.appendChild(indicator);
        chatContainer.scrollTop = chatContainer.scrollHeight;
        return indicator;
    }

    async function sendMessage() {
        const message = userInput.value.trim();
        if (!message) return;

        // Afficher le message utilisateur
        appendMessage(message, true);
        userInput.value = '';

        // Afficher l'indicateur de chargement
        const indicator = showTypingIndicator();

        try {
            const response = await fetch(webhookUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    patient_id: patientID,
                    message: message
                })
            });

            if (!response.ok) {
                throw new Error(`Erreur HTTP: ${response.status}`);
            }

            // Récupération de la réponse en mode texte brut (String)
            const botResponse = await response.text();

            // Retirer l'indicateur
            indicator.remove();

            // Afficher la réponse de l'IA
            appendMessage(botResponse, false);

        } catch (error) {
            console.error('Erreur:', error);
            indicator.remove();
            appendMessage("Désolé, une erreur est survenue lors de la communication avec l'IA. Vérifiez que votre serveur n8n est bien lancé sur le port 5678.", false);
        }
    }

    sendBtn.addEventListener('click', sendMessage);

    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Focus initial
    userInput.focus();
});
