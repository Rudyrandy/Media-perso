require('dotenv').config();
const express = require('express');
const connectDB = require('./config/database');
const doctorRoutes = require('./routes/doctor.routes');
const recommendationRoutes = require('./routes/recommendation.routes');

const app = express();
app.use(express.json());

connectDB();

app.use('/api/doctors', doctorRoutes);
app.use('/api/recommendations', recommendationRoutes);

app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Erreur interne du serveur',
    data: null,
    error: { code: 'INTERNAL_ERROR', details: err.message }
  });
});

module.exports = app;
