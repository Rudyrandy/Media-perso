const Doctor = require('../models/doctor.model');

const normalize = (str) =>
  str.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

const findAll = async ({ name, city, specialty, page, limit }) => {
  const query = { is_verified: true };

  if (city) {
    query.city = { $regex: new RegExp(normalize(city), 'i') };
  }

  if (name) {
    query.name = { $regex: new RegExp(name, 'i') };
  }

  const populateQuery = Doctor.find(query)
    .populate('specialty', 'name code keywords')
    .skip((page - 1) * limit)
    .limit(limit);

  if (specialty) {
    const Specialty = require('../models/specialty.model');
    const found = await Specialty.findOne({ name: { $regex: new RegExp(specialty, 'i') } });
    if (found) query.specialty = found._id;
  }

  const [doctors, total] = await Promise.all([
    Doctor.find(query).populate('specialty', 'name code').skip((page - 1) * limit).limit(limit),
    Doctor.countDocuments(query)
  ]);

  return { doctors, total };
};

module.exports = { findAll };
