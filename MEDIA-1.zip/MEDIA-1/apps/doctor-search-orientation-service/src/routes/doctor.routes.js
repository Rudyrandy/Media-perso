const router = require('express').Router();
const { searchDoctors } = require('../controllers/doctor.controller');

router.get('/', searchDoctors);

module.exports = router;
