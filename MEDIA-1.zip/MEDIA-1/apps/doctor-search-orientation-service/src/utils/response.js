const success = (res, { message = 'OK', data = null, meta = null }, statusCode = 200) => {
  const payload = { success: true, message, data };
  if (meta) payload.meta = meta;
  return res.status(statusCode).json(payload);
};

const error = (res, { message = 'Une erreur est survenue', code = 'INTERNAL_ERROR', details = null }, statusCode = 400) => {
  return res.status(statusCode).json({
    success: false,
    message,
    data: null,
    error: { code, details }
  });
};

module.exports = { success, error };

