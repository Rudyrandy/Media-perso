const doctorService = require('../services/doctor.service');
const { success, error } = require('../utils/response');

const searchDoctors = async (req, res, next) => {
  try {
    const { name, city, specialty, page = 1, limit = 10 } = req.query;

    if (!city && !specialty && !name) {
      return error(res, {
        message: 'Au moins un filtre est requis',
        code: 'SEARCH_001',
        details: 'Fournir au moins un paramètre : name, city ou specialty'
      }, 400);
    }

    const result = await doctorService.searchDoctors({
      name, city, specialty,
      page: parseInt(page),
      limit: parseInt(limit)
    });

    return success(res, {
      message: 'Médecins trouvés',
      data: result.data,
      meta: result.meta
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { searchDoctors };
