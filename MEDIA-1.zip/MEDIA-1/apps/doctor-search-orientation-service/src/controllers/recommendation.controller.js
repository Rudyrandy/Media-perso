const recommendationService = require('../services/recommendation.service');
const { success, error } = require('../utils/response');

const VALID_RISK_LABELS = ['RAS', 'Surveillance', 'Consulter', 'Urgence'];

const getRecommendations = async (req, res, next) => {
  try {
    const { risk_label, diagnostic_text, score } = req.body;

    if (!risk_label || !VALID_RISK_LABELS.includes(risk_label)) {
      return error(res, {
        message: 'Label de risque invalide',
        code: 'RECO_001',
        details: `risk_label doit être : ${VALID_RISK_LABELS.join(', ')}`
      }, 400);
    }

    const result = await recommendationService.getRecommendations({
      risk_label,
      diagnostic_text: diagnostic_text || '',
      score: score || null
    });

    return success(res, {
      message: 'Recommandations générées',
      data: result
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { getRecommendations };
