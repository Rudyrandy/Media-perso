const mongoose = require('mongoose');

const doctorSchema = new mongoose.Schema({
  user_id:        { type: String, required: true, unique: true },
  name:           { type: String, required: true },
  specialty:      { type: mongoose.Schema.Types.ObjectId, ref: 'Specialty', required: true },
  license_number: { type: String, required: true, unique: true },
  hospital:       { type: String, required: true },
  city:           { type: String, required: true },
  bio:            { type: String },
  phone:          { type: String },
  is_verified:    { type: Boolean, default: false },
  available:      { type: Boolean, default: true }
}, { timestamps: true });

// Index pour accélérer les recherches
doctorSchema.index({ city: 1 });
doctorSchema.index({ available: 1 });
doctorSchema.index({ name: 'text', hospital: 'text' });

module.exports = mongoose.model('Doctor', doctorSchema);
