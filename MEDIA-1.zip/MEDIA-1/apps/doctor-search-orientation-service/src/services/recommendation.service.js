const specialtyMap = require('../data/specialty-map.json');

// Mapping label de risque → spécialités recommandées
const riskLevelMap = {
  RAS: {
    message: 'Aucun risque détecté. Aucune consultation spécialisée nécessaire.',
    urgency: 'faible',
    specialties: []
  },
  Surveillance: {
    message: 'Surveillance recommandée. Consultez un médecin généraliste.',
    urgency: 'faible',
    specialties: ['Médecine Générale']
  },
  Consulter: {
    message: 'Consultation spécialisée recommandée.',
    urgency: 'moyenne',
    specialties: null // déterminé par les symptômes
  },
  Urgence: {
    message: 'Consultation urgente requise. Rendez-vous immédiatement chez un spécialiste.',
    urgency: 'haute',
    specialties: null // déterminé par les symptômes
  }
};

const getRecommendations = async ({ risk_label, diagnostic_text, score }) => {
  const riskConfig = riskLevelMap[risk_label];

  if (!riskConfig) {
    return {
      risk_label,
      score,
      message: 'Label de risque non reconnu.',
      specialties: []
    };
  }

  // Pour RAS et Surveillance, pas besoin d'analyser le texte
  if (riskConfig.specialties !== null) {
    return {
      risk_label,
      score,
      urgency: riskConfig.urgency,
      message: riskConfig.message,
      specialties: riskConfig.specialties.map(name => ({ name, reason: riskConfig.message }))
    };
  }

  // Pour Consulter et Urgence, on analyse le texte du diagnostic
  const diagnosticLower = (diagnostic_text || '').toLowerCase();
  const matched = specialtyMap.filter(entry =>
    entry.keywords.some(keyword => diagnosticLower.includes(keyword))
  );

  const specialties = matched.length > 0
    ? matched.map(m => ({ name: m.specialty, reason: m.reason }))
    : [{ name: 'Médecine Générale', reason: 'Aucune spécialité précise identifiée' }];

  return {
    risk_label,
    score,
    urgency: riskConfig.urgency,
    message: riskConfig.message,
    specialties
  };
};

module.exports = { getRecommendations };
