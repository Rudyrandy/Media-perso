const doctorRepository = require('../repositories/doctor.repository');

const searchDoctors = async ({ name, city, specialty, page, limit }) => {
  const { doctors, total } = await doctorRepository.findAll({ name, city, specialty, page, limit });

  return {
    data: doctors,
    meta: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit)
    }
  };
};

module.exports = { searchDoctors };
