require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./database');
const Doctor = require('../models/doctor.model');
const Specialty = require('../models/specialty.model');

const specialties = [
  { code: 'CARD', name: 'Cardiologie',     keywords: ['coeur', 'palpitations', 'douleur thoracique', 'hypertension', 'essoufflement'] },
  { code: 'NEUR', name: 'Neurologie',      keywords: ['maux de tête', 'migraine', 'vertiges', 'engourdissement', 'convulsions'] },
  { code: 'DERM', name: 'Dermatologie',    keywords: ['éruption', 'boutons', 'peau', 'démangeaison', 'eczéma', 'acné'] },
  { code: 'PEDI', name: 'Pédiatrie',       keywords: ['enfant', 'nourrisson', 'fièvre enfant', 'croissance'] },
  { code: 'GYNE', name: 'Gynécologie',     keywords: ['règles', 'grossesse', 'douleur pelvienne', 'ovaires'] },
  { code: 'OPHT', name: 'Ophtalmologie',   keywords: ['yeux', 'vue', 'vision', 'cataracte', 'glaucome'] },
  { code: 'GENE', name: 'Médecine Générale', keywords: [] }
];

const doctorSeeds = [
  { user_id: 'usr_001', name: 'Dr. Alice Mbarga',   specialty_code: 'CARD', license_number: 'CM-CARD-0001', hospital: 'Hôpital Central de Yaoundé',    city: 'Yaoundé',   phone: '+237600000001', is_verified: true,  available: true  },
  { user_id: 'usr_002', name: 'Dr. Bruno Essono',   specialty_code: 'NEUR', license_number: 'CM-NEUR-0002', hospital: 'Clinique des Palmiers',          city: 'Douala',    phone: '+237600000002', is_verified: true,  available: true  },
  { user_id: 'usr_003', name: 'Dr. Claire Ngo',     specialty_code: 'DERM', license_number: 'CM-DERM-0003', hospital: 'Hôpital Central de Yaoundé',    city: 'Yaoundé',   phone: '+237600000003', is_verified: true,  available: false },
  { user_id: 'usr_004', name: 'Dr. David Atangana', specialty_code: 'PEDI', license_number: 'CM-PEDI-0004', hospital: 'Hôpital Régional de Bafoussam', city: 'Bafoussam', phone: '+237600000004', is_verified: true,  available: true  },
  { user_id: 'usr_005', name: 'Dr. Estelle Owona',  specialty_code: 'GYNE', license_number: 'CM-GYNE-0005', hospital: 'Clinique La Grâce',             city: 'Douala',    phone: '+237600000005', is_verified: true,  available: true  },
  { user_id: 'usr_006', name: 'Dr. Frank Biya',     specialty_code: 'OPHT', license_number: 'CM-OPHT-0006', hospital: 'Centre Médical Bastos',         city: 'Yaoundé',   phone: '+237600000006', is_verified: true,  available: true  },
  { user_id: 'usr_007', name: 'Dr. Grace Manga',    specialty_code: 'GENE', license_number: 'CM-GENE-0007', hospital: 'Centre de Santé Nlongkak',      city: 'Yaoundé',   phone: '+237600000007', is_verified: true,  available: true  }
];

const seed = async () => {
  await connectDB();

  // Nettoyage
  await Doctor.deleteMany({});
  await Specialty.deleteMany({});
  console.log('Collections nettoyées 🧹');

  // Insertion des spécialités
  const insertedSpecialties = await Specialty.insertMany(specialties);
  console.log(`${insertedSpecialties.length} spécialités insérées ✅`);

  // Mapping code → _id
  const specialtyMap = {};
  insertedSpecialties.forEach(s => specialtyMap[s.code] = s._id);

  // Insertion des médecins
  const doctors = doctorSeeds.map(({ specialty_code, ...d }) => ({
    ...d,
    specialty: specialtyMap[specialty_code]
  }));

  const insertedDoctors = await Doctor.insertMany(doctors);
  console.log(`${insertedDoctors.length} médecins insérés ✅`);

  await mongoose.disconnect();
  console.log('Seed terminé 🎉');
};

seed().catch(err => {
  console.error('Erreur seed :', err);
  process.exit(1);
});
