<?php

/**
 * Fichier de test pour vérifier la connexion à MongoDB
 * Exécutez ce fichier avec : php test-mongodb.php
 */

// Charger l'autoloader de Composer
require_once __DIR__ . '/vendor/autoload.php';

// Charger les variables d'environnement
function loadEnv($path) {
    if (!file_exists($path)) {
        return false;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        if (strpos($line, '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            $value = trim($value, '"\'');
            $_ENV[$name] = $value;
            putenv("$name=$value");
        }
    }
    return true;
}

loadEnv(__DIR__ . '/.env');

echo "=== Test de connexion à MongoDB ===\n\n";

try {
    // Récupérer les variables d'environnement
    $mongoUri = $_ENV['MONGO_URI'] ?? 'mongodb://localhost:27017';
    $mongoDatabase = $_ENV['MONGO_DATABASE'] ?? 'test';

    echo "1. Tentative de connexion...\n";
    echo "   URI : " . $mongoUri . "\n";
    echo "   Database : " . $mongoDatabase . "\n\n";

    // Créer le client MongoDB
    $client = new MongoDB\Client($mongoUri);

    // Tester la connexion
    echo "2. Test de connexion au serveur...\n";
    $client->selectDatabase('admin')->command(['ping' => 1]);
    echo "   ✓ Connexion réussie !\n\n";

    // Lister les bases de données
    echo "3. Liste des bases de données :\n";
    $databases = $client->listDatabases();
    foreach ($databases as $db) {
        echo "   - " . $db->getName() . "\n";
    }
    echo "\n";

    // Tester l'accès à la base de données cible
    echo "4. Test d'accès à la base '$mongoDatabase' :\n";
    $db = $client->selectDatabase($mongoDatabase);
    echo "   ✓ Base de données accessible\n\n";

    // Lister les collections de la base
    echo "5. Collections dans '$mongoDatabase' :\n";
    $collections = $db->listCollections();
    if (empty($collections)) {
        echo "   (Aucune collection)\n";
    } else {
        foreach ($collections as $collection) {
            echo "   - " . $collection->getName() . "\n";
        }
    }
    echo "\n";

    echo "=== Tous les tests sont passés avec succès ! ===\n";

} catch (MongoDB\Driver\Exception\Exception $e) {
    echo "   ✗ Erreur MongoDB : " . $e->getMessage() . "\n\n";
    echo "=== Vérifiez votre configuration MongoDB et le fichier .env ===\n";
    exit(1);
} catch (Exception $e) {
    echo "   ✗ Erreur : " . $e->getMessage() . "\n\n";
    exit(1);
}
