<?php

require_once __DIR__ . '/../services/ArticleService.php';
require_once __DIR__ . '/../utils/Response.php';

/**
 * Controller Article
 * Gère les requêtes HTTP pour les articles
 */
class ArticleController {
    private ArticleService $service;

    public function __construct() {
        $this->service = new ArticleService();
    }

    /**
     * Crée un nouvel article
     * Méthode HTTP : POST
     * Endpoint : /articles
     */
    public function create(): void {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);

        if ($data === null) {
            Response::error('Données JSON invalides', 'INVALID_JSON', 'Le corps de la requête doit être un JSON valide');
            return;
        }

        $result = $this->service->createArticle($data);

        if ($result['success']) {
            $article = $result['article'];
            Response::success('Article créé avec succès', $article->toArray(), 201);
        } else {
            Response::error('Erreur lors de la création de l\'article', 'CREATE_ERROR', $result['error']);
        }
    }

    /**
     * Récupère tous les articles publiés
     * Méthode HTTP : GET
     * Endpoint : /articles
     */
    public function index(): void {
        $filters = $_GET;
        unset($filters['page'], $filters['limit']);
        
        $result = $this->service->getPublishedArticles($filters);

        if ($result['success']) {
            $articles = array_map(function($article) {
                return $article->toArray();
            }, $result['articles']);
            Response::success('Articles récupérés avec succès', $articles);
        } else {
            Response::error('Erreur lors de la récupération des articles', 'FETCH_ERROR', $result['error']);
        }
    }

    /**
     * Récupère un article par son ID
     * Méthode HTTP : GET
     * Endpoint : /articles/{id}
     */
    public function show(string $id): void {
        $result = $this->service->getArticleById($id);

        if ($result['success']) {
            Response::success('Article récupéré avec succès', $result['article']->toArray());
        } else {
            Response::error('Article non trouvé', 'NOT_FOUND', $result['error'], 404);
        }
    }

    /**
     * Met à jour un article
     * Méthode HTTP : PUT
     * Endpoint : /articles/{id}
     */
    public function update(string $id): void {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);

        if ($data === null) {
            Response::error('Données JSON invalides', 'INVALID_JSON', 'Le corps de la requête doit être un JSON valide');
            return;
        }

        $result = $this->service->updateArticle($id, $data);

        if ($result['success']) {
            Response::success('Article mis à jour avec succès', $result['article']->toArray());
        } else {
            Response::error('Erreur lors de la mise à jour de l\'article', 'UPDATE_ERROR', $result['error']);
        }
    }

    /**
     * Publie un article
     * Méthode HTTP : PATCH
     * Endpoint : /articles/{id}/publish
     */
    public function publish(string $id): void {
        $result = $this->service->publishArticle($id);

        if ($result['success']) {
            Response::success('Article publié avec succès', $result['article']->toArray());
        } else {
            Response::error('Erreur lors de la publication de l\'article', 'PUBLISH_ERROR', $result['error']);
        }
    }

    /**
     * Dépublie un article
     * Méthode HTTP : PATCH
     * Endpoint : /articles/{id}/unpublish
     */
    public function unpublish(string $id): void {
        $result = $this->service->unpublishArticle($id);

        if ($result['success']) {
            Response::success('Article dépublié avec succès', $result['article']->toArray());
        } else {
            Response::error('Erreur lors de la dépublication de l\'article', 'UNPUBLISH_ERROR', $result['error']);
        }
    }

}
