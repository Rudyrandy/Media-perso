<?php

require_once __DIR__ . '/../services/ArticleInteractionService.php';
require_once __DIR__ . '/../utils/Response.php';

/**
 * Controller ArticleInteraction
 * Gère les requêtes HTTP pour les interactions sur les articles
 */
class ArticleInteractionController {
    private ArticleInteractionService $service;

    public function __construct() {
        $this->service = new ArticleInteractionService();
    }

    /**
     * Ajoute une interaction (like ou view)
     * Méthode HTTP : POST
     * Endpoint : /articles/{id}/interactions
     */
    public function addInteraction(string $articleId): void {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);

        if ($data === null) {
            Response::error('Données JSON invalides', 'INVALID_JSON', 'Le corps de la requête doit être un JSON valide');
            return;
        }

        $data['articleId'] = $articleId;

        $result = $this->service->addInteraction($data);

        if ($result['success']) {
            Response::success('Interaction enregistrée avec succès', ['id' => $result['id']], 201);
        } else {
            Response::error('Erreur lors de l\'ajout de l\'interaction', 'ADD_ERROR', $result['error']);
        }
    }

    /**
     * Retire une interaction
     * Méthode HTTP : DELETE
     * Endpoint : /articles/{id}/interactions
     */
    public function removeInteraction(string $articleId): void {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);

        if ($data === null) {
            Response::error('Données JSON invalides', 'INVALID_JSON', 'Le corps de la requête doit être un JSON valide');
            return;
        }

        $data['articleId'] = $articleId;

        $result = $this->service->removeInteraction($data);

        if ($result['success']) {
            Response::success('Interaction retirée avec succès', null);
        } else {
            Response::error('Erreur lors du retrait de l\'interaction', 'REMOVE_ERROR', $result['error']);
        }
    }

    /**
     * Compte les interactions par type
     * Méthode HTTP : GET
     * Endpoint : /articles/{id}/interactions/count?type=like|view
     */
    public function countByType(string $articleId): void {
        $type = $_GET['type'] ?? 'like';

        if (!in_array($type, ['like', 'view'])) {
            Response::error('Type invalide', 'INVALID_TYPE', 'type doit être "like" ou "view"');
            return;
        }

        $result = $this->service->countByType($articleId, $type);

        if ($result['success']) {
            Response::success('Comptage réussi', ['count' => $result['count']]);
        } else {
            Response::error('Erreur lors du comptage', 'COUNT_ERROR', $result['error']);
        }
    }

    /**
     * Compte toutes les interactions d'un article
     * Méthode HTTP : GET
     * Endpoint : /articles/{id}/stats
     */
    public function countAll(string $articleId): void {
        $result = $this->service->countAll($articleId);

        if ($result['success']) {
            Response::success('Stats récupérées avec succès', [
                'likes' => $result['likes'],
                'views' => $result['views']
            ]);
        } else {
            Response::error('Erreur lors de la récupération des stats', 'STATS_ERROR', $result['error']);
        }
    }

    /**
     * Vérifie si une interaction existe
     * Méthode HTTP : GET
     * Endpoint : /articles/{id}/interactions/check
     */
    public function hasInteracted(string $articleId): void {
        $data = [
            'articleId' => $articleId,
            'type' => $_GET['type'] ?? 'like',
            'userId' => $_GET['userId'] ?? null,
            'patientId' => $_GET['patientId'] ?? null
        ];

        $result = $this->service->hasInteracted($data);

        if ($result['success']) {
            Response::success('Vérification réussie', ['interacted' => $result['interacted']]);
        } else {
            Response::error('Erreur lors de la vérification', 'CHECK_ERROR', $result['error']);
        }
    }

}
