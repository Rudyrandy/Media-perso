<?php

require_once __DIR__ . '/../../vendor/autoload.php';
require_once __DIR__ . '/../config/mongodb.php';

/**
 * Repository ArticleInteraction
 * Gère les interactions sur les articles dans MongoDB
 */
class ArticleInteractionRepository {
    private $db;
    private $collection;

    public function __construct() {
        $this->db = getMongoDatabase();
        $this->collection = $this->db->article_interactions;
    }

    /**
     * Ajoute une interaction (like ou view)
     * 
     * @param array $data Les données de l'interaction
     * @return string L'ID de l'interaction créée
     */
    public function add(array $data): string {
        $articleIdRaw = $data['articleId'] ?? null;
        try {
            $articleObjectId = new MongoDB\BSON\ObjectId((string) $articleIdRaw);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            throw new InvalidArgumentException('articleId invalide');
        }

        $document = [
            'articleId' => $articleObjectId,
            'type' => $data['type'] ?? 'view',
            'createdAt' => new MongoDB\BSON\UTCDateTime()
        ];

        // userId est requis par le schéma
        if (empty($data['userId'])) {
            throw new InvalidArgumentException('userId est requis par le schéma MongoDB');
        }

        try {
            $document['userId'] = new MongoDB\BSON\ObjectId((string) $data['userId']);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            throw new InvalidArgumentException('userId invalide');
        }

        // patientId est optionnel
        if (!empty($data['patientId'])) {
            try {
                $document['patientId'] = new MongoDB\BSON\ObjectId((string) $data['patientId']);
            } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
                throw new InvalidArgumentException('patientId invalide');
            }
        }

        $result = $this->collection->insertOne($document);
        return $result->getInsertedId()->__toString();
    }

    /**
     * Retire une interaction
     * 
     * @param string $articleId L'ID de l'article
     * @param string $userId L'ID de l'utilisateur (optionnel)
     * @param string $patientId L'ID du patient (optionnel)
     * @param string $type Le type d'interaction
     * @return bool True si supprimé, false sinon
     */
    public function remove(string $articleId, ?string $userId = null, ?string $patientId = null, string $type = 'like'): bool {
        try {
            $articleObjectId = new MongoDB\BSON\ObjectId($articleId);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return false;
        }

        $filter = [
            'articleId' => $articleObjectId,
            'type' => $type
        ];

        if ($userId !== null) {
            try {
                $filter['userId'] = new MongoDB\BSON\ObjectId($userId);
            } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
                return false;
            }
        }

        if ($patientId !== null) {
            try {
                $filter['patientId'] = new MongoDB\BSON\ObjectId($patientId);
            } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
                return false;
            }
        }

        $result = $this->collection->deleteOne($filter);
        return $result->getDeletedCount() > 0;
    }

    /**
     * Compte les interactions d'un article par type
     * 
     * @param string $articleId L'ID de l'article
     * @param string $type Le type d'interaction (like ou view)
     * @return int Le nombre d'interactions
     */
    public function countByType(string $articleId, string $type): int {
        try {
            $articleObjectId = new MongoDB\BSON\ObjectId($articleId);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return 0;
        }

        return $this->collection->countDocuments([
            'articleId' => $articleObjectId,
            'type' => $type
        ]);
    }

    /**
     * Vérifie si une interaction existe
     * 
     * @param string $articleId L'ID de l'article
     * @param string $userId L'ID de l'utilisateur (optionnel)
     * @param string $patientId L'ID du patient (optionnel)
     * @param string $type Le type d'interaction
     * @return bool True si existe, false sinon
     */
    public function hasInteracted(string $articleId, ?string $userId = null, ?string $patientId = null, string $type = 'like'): bool {
        try {
            $articleObjectId = new MongoDB\BSON\ObjectId($articleId);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return false;
        }

        $filter = [
            'articleId' => $articleObjectId,
            'type' => $type
        ];

        if ($userId !== null) {
            try {
                $filter['userId'] = new MongoDB\BSON\ObjectId($userId);
            } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
                return false;
            }
        }

        if ($patientId !== null) {
            try {
                $filter['patientId'] = new MongoDB\BSON\ObjectId($patientId);
            } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
                return false;
            }
        }

        $count = $this->collection->countDocuments($filter);
        return $count > 0;
    }

    /**
     * Compte toutes les interactions d'un article
     * 
     * @param string $articleId L'ID de l'article
     * @return array ['likes' => int, 'views' => int]
     */
    public function countAll(string $articleId): array {
        try {
            $articleObjectId = new MongoDB\BSON\ObjectId($articleId);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return ['likes' => 0, 'views' => 0];
        }

        $likes = $this->collection->countDocuments([
            'articleId' => $articleObjectId,
            'type' => 'like'
        ]);

        $views = $this->collection->countDocuments([
            'articleId' => $articleObjectId,
            'type' => 'view'
        ]);

        return ['likes' => $likes, 'views' => $views];
    }
}
