<?php

require_once __DIR__ . '/../config/mongodb.php';
require_once __DIR__ . '/../models/Article.php';

/**
 * Repository Article
 * Gère l'accès à MongoDB pour les articles
 */
class ArticleRepository {
    private MongoDB\Database $db;
    private MongoDB\Collection $collection;

    public function __construct() {
        $this->db = getMongoDatabase();
        $this->collection = $this->db->articles;
    }

    /**
     * Crée un nouvel article
     * 
     * @param array $data Les données de l'article
     * @return string L'ID de l'article créé
     */
    public function create(array $data): string {
        $title = $data['title'];
        $slug = $data['slug'] ?? strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
        
        // Si slug fourni manuellement, on l'utilise tel quel
        // Sinon, on ajoute un suffixe unique pour éviter les doublons
        if (!isset($data['slug'])) {
            $slug = $slug . '-' . bin2hex(random_bytes(4)); // suffixe 8 caractères hex
        }

        $doctorIdRaw = $data['doctorId'] ?? $data['doctor_profile_id'] ?? null;
        try {
            $doctorObjectId = new MongoDB\BSON\ObjectId((string) $doctorIdRaw);
        } catch (Exception $e) {
            throw new InvalidArgumentException('doctorId invalide : doit être un ObjectId valide (24 hex)');
        }

        $document = [
            'doctorId' => $doctorObjectId,
            'title' => $title,
            'slug' => $slug,
            'content' => $data['content'],
            'language' => $data['language'] ?? 'fr',
            'status' => 'draft',
            'stats' => ['views' => 0, 'likes' => 0],
            'createdAt' => new MongoDB\BSON\UTCDateTime(),
            'updatedAt' => new MongoDB\BSON\UTCDateTime()
        ];

        $result = $this->collection->insertOne($document);
        return $result->getInsertedId()->__toString();
    }

    /**
     * Récupère un article par son ID
     * 
     * @param string $id L'ID de l'article
     * @return Article|null L'article ou null si non trouvé
     */
    public function findById(string $id): ?Article {
        try {
            $objectId = new MongoDB\BSON\ObjectId($id);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return null;
        }

        $document = $this->collection->findOne(['_id' => $objectId]);

        if ($document) {
            return new Article($document->getArrayCopy());
        }

        return null;
    }

    /**
     * Récupère les articles publiés avec filtres
     * 
     * @param array $filters Les filtres de recherche
     * @return array La liste des articles
     */
    public function findPublished(array $filters = []): array {
        $query = array_merge(['status' => 'published'], $filters);
        $cursor = $this->collection->find($query);

        $articles = [];
        foreach ($cursor as $document) {
            $articles[] = new Article($document->getArrayCopy());
        }

        return $articles;
    }

    /**
     * Met à jour un article
     * 
     * @param string $id L'ID de l'article
     * @param array $data Les données à mettre à jour
     * @return bool True si mis à jour, false sinon
     */
    public function update(string $id, array $data): bool {
        try {
            $objectId = new MongoDB\BSON\ObjectId($id);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return false;
        }

        $updateData = array_merge($data, ['updatedAt' => new MongoDB\BSON\UTCDateTime()]);
        
        $result = $this->collection->updateOne(
            ['_id' => $objectId],
            ['$set' => $updateData]
        );

        return $result->getModifiedCount() > 0;
    }

    /**
     * Publie un article
     * 
     * @param string $id L'ID de l'article
     * @return bool True si publié, false sinon
     */
    public function publish(string $id): bool {
        try {
            $objectId = new MongoDB\BSON\ObjectId($id);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return false;
        }

        $result = $this->collection->updateOne(
            ['_id' => $objectId],
            [
                '$set' => [
                    'status' => 'published',
                    'publishedAt' => new MongoDB\BSON\UTCDateTime(),
                    'updatedAt' => new MongoDB\BSON\UTCDateTime()
                ]
            ]
        );

        return $result->getModifiedCount() > 0;
    }

    /**
     * Dépublie un article
     * 
     * @param string $id L'ID de l'article
     * @return bool True si dépublié, false sinon
     */
    public function unpublish(string $id): bool {
        try {
            $objectId = new MongoDB\BSON\ObjectId($id);
        } catch (MongoDB\Driver\Exception\InvalidArgumentException $e) {
            return false;
        }

        $result = $this->collection->updateOne(
            ['_id' => $objectId],
            [
                '$set' => ['status' => 'draft', 'updatedAt' => new MongoDB\BSON\UTCDateTime()],
                '$unset' => ['publishedAt' => '']
            ]
        );

        return $result->getModifiedCount() > 0;
    }
}
