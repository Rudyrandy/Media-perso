<?php

require_once __DIR__ . '/../../vendor/autoload.php';

/**
 * Model ArticleInteraction
 * Représente une interaction sur un article (like ou view) dans MongoDB
 */
class ArticleInteraction {
    private ?MongoDB\BSON\ObjectId $_id;
    private MongoDB\BSON\ObjectId $articleId;
    private ?MongoDB\BSON\ObjectId $userId;
    private ?MongoDB\BSON\ObjectId $patientId;
    private string $type;
    private MongoDB\BSON\UTCDateTime $createdAt;

    public function __construct(array $data = []) {
        $this->_id = $data['_id'] ?? null;

        $articleIdRaw = $data['articleId'] ?? null;
        if ($articleIdRaw instanceof MongoDB\BSON\ObjectId) {
            $this->articleId = $articleIdRaw;
        } elseif (!empty($articleIdRaw)) {
            try {
                $this->articleId = new MongoDB\BSON\ObjectId((string) $articleIdRaw);
            } catch (Exception $e) {
                throw new InvalidArgumentException('articleId invalide : doit être un ObjectId valide');
            }
        } else {
            throw new InvalidArgumentException('articleId est obligatoire');
        }

        $userIdRaw = $data['userId'] ?? null;
        if ($userIdRaw instanceof MongoDB\BSON\ObjectId) {
            $this->userId = $userIdRaw;
        } elseif (!empty($userIdRaw)) {
            try {
                $this->userId = new MongoDB\BSON\ObjectId((string) $userIdRaw);
            } catch (Exception $e) {
                $this->userId = null;
            }
        } else {
            $this->userId = null;
        }

        $patientIdRaw = $data['patientId'] ?? null;
        if ($patientIdRaw instanceof MongoDB\BSON\ObjectId) {
            $this->patientId = $patientIdRaw;
        } elseif (!empty($patientIdRaw)) {
            try {
                $this->patientId = new MongoDB\BSON\ObjectId((string) $patientIdRaw);
            } catch (Exception $e) {
                $this->patientId = null;
            }
        } else {
            $this->patientId = null;
        }

        $this->type = $data['type'] ?? 'view';
        $this->createdAt = $data['createdAt'] ?? new MongoDB\BSON\UTCDateTime();
    }

    public function getId(): ?MongoDB\BSON\ObjectId {
        return $this->_id;
    }

    public function setId(MongoDB\BSON\ObjectId $id): void {
        $this->_id = $id;
    }

    public function getArticleId(): MongoDB\BSON\ObjectId {
        return $this->articleId;
    }

    public function setArticleId(MongoDB\BSON\ObjectId $articleId): void {
        $this->articleId = $articleId;
    }

    public function getUserId(): ?MongoDB\BSON\ObjectId {
        return $this->userId;
    }

    public function setUserId(?MongoDB\BSON\ObjectId $userId): void {
        $this->userId = $userId;
    }

    public function getPatientId(): ?MongoDB\BSON\ObjectId {
        return $this->patientId;
    }

    public function setPatientId(?MongoDB\BSON\ObjectId $patientId): void {
        $this->patientId = $patientId;
    }

    public function getType(): string {
        return $this->type;
    }

    public function setType(string $type): void {
        $this->type = $type;
    }

    public function getCreatedAt(): MongoDB\BSON\UTCDateTime {
        return $this->createdAt;
    }

    public function setCreatedAt(MongoDB\BSON\UTCDateTime $createdAt): void {
        $this->createdAt = $createdAt;
    }

    public function toArray(): array {
        return [
            '_id' => $this->_id ? (string) $this->_id : null,
            'articleId' => (string) $this->articleId,
            'userId' => $this->userId ? (string) $this->userId : null,
            'patientId' => $this->patientId ? (string) $this->patientId : null,
            'type' => $this->type,
            'createdAt' => $this->createdAt->toDateTime()->format('c')
        ];
    }

    public function toMongoArray(): array {
        $data = [
            'articleId' => $this->articleId,
            'type' => $this->type,
            'createdAt' => $this->createdAt
        ];

        if ($this->userId !== null) {
            $data['userId'] = $this->userId;
        }

        if ($this->patientId !== null) {
            $data['patientId'] = $this->patientId;
        }

        if ($this->_id !== null) {
            $data['_id'] = $this->_id;
        }

        return $data;
    }
}
