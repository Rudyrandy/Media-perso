<?php

require_once __DIR__ . '/../../vendor/autoload.php';

/**
 * Model Article
 * Représente un article dans MongoDB
 */
class Article {
    private ?MongoDB\BSON\ObjectId $_id;
    private ?MongoDB\BSON\ObjectId $doctorId;
    private string $title;
    private string $slug;
    private string $content;
    private string $language;
    private string $status;
    private array $stats;
    private ?MongoDB\BSON\UTCDateTime $publishedAt;
    private ?MongoDB\BSON\UTCDateTime $createdAt;
    private ?MongoDB\BSON\UTCDateTime $updatedAt;

    public function __construct(array $data = []) {
        $this->_id = $data['_id'] ?? null;

        $doctorIdRaw = $data['doctorId'] ?? $data['doctor_profile_id'] ?? null;
        if ($doctorIdRaw instanceof MongoDB\BSON\ObjectId) {
            $this->doctorId = $doctorIdRaw;
        } elseif (!empty($doctorIdRaw)) {
            try {
                $this->doctorId = new MongoDB\BSON\ObjectId((string) $doctorIdRaw);
            } catch (Exception $e) {
                $this->doctorId = null;
            }
        } else {
            $this->doctorId = null;
        }

        $this->title = $data['title'] ?? '';
        $this->slug = $data['slug'] ?? '';
        $this->content = $data['content'] ?? '';
        $this->language = $data['language'] ?? 'fr';
        $this->status = $data['status'] ?? 'draft';
        $statsRaw = $data['stats'] ?? [];
        $this->stats = [
            'views' => (int) ($statsRaw['views'] ?? 0),
            'likes' => (int) ($statsRaw['likes'] ?? 0)
        ];
        $this->publishedAt = $data['publishedAt'] ?? $data['published_at'] ?? null;
        $this->createdAt = $data['createdAt'] ?? $data['created_at'] ?? null;
        $this->updatedAt = $data['updatedAt'] ?? $data['updated_at'] ?? null;
    }

    public function getId(): ?MongoDB\BSON\ObjectId {
        return $this->_id;
    }

    public function setId(MongoDB\BSON\ObjectId $id): void {
        $this->_id = $id;
    }

    public function getDoctorId(): ?MongoDB\BSON\ObjectId {
        return $this->doctorId;
    }

    public function setDoctorId(MongoDB\BSON\ObjectId $doctorId): void {
        $this->doctorId = $doctorId;
    }

    public function getSlug(): string {
        return $this->slug;
    }

    public function setSlug(string $slug): void {
        $this->slug = $slug;
    }

    public function getStatus(): string {
        return $this->status;
    }

    public function setStatus(string $status): void {
        $this->status = $status;
    }

    public function isPublished(): bool {
        return $this->status === 'published';
    }

    public function getTitle(): string {
        return $this->title;
    }

    public function setTitle(string $title): void {
        $this->title = $title;
    }

    public function getContent(): string {
        return $this->content;
    }

    public function setContent(string $content): void {
        $this->content = $content;
    }

    public function getCategory(): string {
        return $this->category;
    }

    public function setCategory(string $category): void {
        $this->category = $category;
    }

    public function getLanguage(): string {
        return $this->language;
    }

    public function setLanguage(string $language): void {
        $this->language = $language;
    }

    public function getPublishedAt(): ?MongoDB\BSON\UTCDateTime {
        return $this->publishedAt;
    }

    public function setPublishedAt(?MongoDB\BSON\UTCDateTime $publishedAt): void {
        $this->publishedAt = $publishedAt;
    }

    public function getCreatedAt(): ?MongoDB\BSON\UTCDateTime {
        return $this->createdAt;
    }

    public function getUpdatedAt(): ?MongoDB\BSON\UTCDateTime {
        return $this->updatedAt;
    }

    public function toArray(): array {
        return [
            '_id' => $this->_id ? (string) $this->_id : null,
            'doctorId' => $this->doctorId ? (string) $this->doctorId : null,
            'title' => $this->title,
            'slug' => $this->slug,
            'content' => $this->content,
            'language' => $this->language,
            'status' => $this->status,
            'stats' => $this->stats,
            'publishedAt' => $this->publishedAt ? $this->publishedAt->toDateTime()->format('c') : null,
            'createdAt' => $this->createdAt ? $this->createdAt->toDateTime()->format('c') : null,
            'updatedAt' => $this->updatedAt ? $this->updatedAt->toDateTime()->format('c') : null
        ];
    }

    public function toMongoArray(): array {
        $data = [
            'doctorId' => $this->doctorId,
            'title' => $this->title,
            'slug' => $this->slug,
            'content' => $this->content,
            'language' => $this->language,
            'status' => $this->status,
            'stats' => $this->stats,
            'createdAt' => $this->createdAt,
            'updatedAt' => $this->updatedAt
        ];

        if ($this->publishedAt !== null) {
            $data['publishedAt'] = $this->publishedAt;
        }

        if ($this->_id !== null) {
            $data['_id'] = $this->_id;
        }

        return $data;
    }
}
