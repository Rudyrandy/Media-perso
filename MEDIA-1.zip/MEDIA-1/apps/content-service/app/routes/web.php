<?php

require_once __DIR__ . '/../controllers/ArticleController.php';
require_once __DIR__ . '/../controllers/ArticleInteractionController.php';

/**
 * Routes de l'application
 * Définit les endpoints de l'API
 */

// Récupération de la méthode HTTP et du chemin
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

// Suppression du éventuel / de fin
$path = rtrim($path, '/');

// Regex pour MongoDB ObjectId (24 caractères hexadécimaux)
$objectIdPattern = '[0-9a-fA-F]{24}';

// Router simple
switch ($path) {
    case '/articles':
        $controller = new ArticleController();
        
        if ($method === 'POST') {
            $controller->create();
        } elseif ($method === 'GET') {
            $controller->index();
        } else {
            http_response_code(405);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
        }
        break;

    default:
        // Routes avec paramètres dynamiques pour les articles
        if (preg_match("#^/articles/($objectIdPattern)$#", $path, $matches)) {
            $articleId = $matches[1];
            $controller = new ArticleController();
            
            if ($method === 'GET') {
                $controller->show($articleId);
            } elseif ($method === 'PUT') {
                $controller->update($articleId);
            } else {
                http_response_code(405);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
            }
        }
        // Routes pour publish/unpublish
        elseif (preg_match("#^/articles/($objectIdPattern)/publish$#", $path, $matches)) {
            $articleId = $matches[1];
            $controller = new ArticleController();
            
            if ($method === 'PATCH') {
                $controller->publish($articleId);
            } else {
                http_response_code(405);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
            }
        }
        elseif (preg_match("#^/articles/($objectIdPattern)/unpublish$#", $path, $matches)) {
            $articleId = $matches[1];
            $controller = new ArticleController();
            
            if ($method === 'PATCH') {
                $controller->unpublish($articleId);
            } else {
                http_response_code(405);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
            }
        }
        // Routes pour les interactions (likes et views unifiés)
        elseif (preg_match("#^/articles/($objectIdPattern)/interactions$#", $path, $matches)) {
            $articleId = $matches[1];
            $controller = new ArticleInteractionController();
            
            if ($method === 'POST') {
                $controller->addInteraction($articleId);
            } elseif ($method === 'DELETE') {
                $controller->removeInteraction($articleId);
            } else {
                http_response_code(405);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
            }
        }
        elseif (preg_match("#^/articles/($objectIdPattern)/interactions/count$#", $path, $matches)) {
            $articleId = $matches[1];
            $controller = new ArticleInteractionController();
            
            if ($method === 'GET') {
                $controller->countByType($articleId);
            } else {
                http_response_code(405);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
            }
        }
        elseif (preg_match("#^/articles/($objectIdPattern)/interactions/check$#", $path, $matches)) {
            $articleId = $matches[1];
            $controller = new ArticleInteractionController();
            
            if ($method === 'GET') {
                $controller->hasInteracted($articleId);
            } else {
                http_response_code(405);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
            }
        }
        // Route pour les stats (likes + views)
        elseif (preg_match("#^/articles/($objectIdPattern)/stats$#", $path, $matches)) {
            $articleId = $matches[1];
            $controller = new ArticleInteractionController();
            
            if ($method === 'GET') {
                $controller->countAll($articleId);
            } else {
                http_response_code(405);
                header('Content-Type: application/json');
                echo json_encode(['error' => 'Méthode non autorisée'], JSON_UNESCAPED_UNICODE);
            }
        }
        else {
            http_response_code(404);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Route non trouvée'], JSON_UNESCAPED_UNICODE);
        }
        break;
}
