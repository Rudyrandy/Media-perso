<?php

require_once __DIR__ . '/../repositories/ArticleRepository.php';
require_once __DIR__ . '/../models/Article.php';

/**
 * Service Article
 * Gère la logique métier pour les articles
 */
class ArticleService {
    private ArticleRepository $repository;

    public function __construct() {
        $this->repository = new ArticleRepository();
    }

    /**
     * Crée un nouvel article après validation
     * 
     * @param array $data Les données de l'article
     * @return array Le résultat de la création
     */
    public function createArticle(array $data): array {
        // Validation des données
        $validation = $this->validate($data);
        if (!$validation['valid']) {
            return [
                'success' => false,
                'error' => $validation['error']
            ];
        }

        // Insertion en base
        try {
            $id = $this->repository->create($data);
        } catch (InvalidArgumentException $e) {
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }

        $article = $this->repository->findById($id);

        return [
            'success' => true,
            'article' => $article
        ];
    }

    /**
     * Récupère tous les articles publiés
     * 
     * @param array $filters Les filtres de recherche
     * @return array Le résultat avec la liste des articles
     */
    public function getPublishedArticles(array $filters = []): array {
        $articles = $this->repository->findPublished($filters);
        return [
            'success' => true,
            'articles' => $articles
        ];
    }

    /**
     * Récupère un article par son ID
     * 
     * @param string $id L'ID de l'article
     * @return array Le résultat avec l'article
     */
    public function getArticleById(string $id): array {
        $article = $this->repository->findById($id);

        if (!$article) {
            return [
                'success' => false,
                'error' => 'Article non trouvé'
            ];
        }

        return [
            'success' => true,
            'article' => $article
        ];
    }

    /**
     * Met à jour un article
     * 
     * @param string $id L'ID de l'article
     * @param array $data Les données à mettre à jour
     * @return array Le résultat de la mise à jour
     */
    public function updateArticle(string $id, array $data): array {
        $article = $this->repository->findById($id);

        if (!$article) {
            return [
                'success' => false,
                'error' => 'Article non trouvé'
            ];
        }

        $updated = $this->repository->update($id, $data);

        if (!$updated) {
            return [
                'success' => false,
                'error' => 'Erreur lors de la mise à jour'
            ];
        }

        $updatedArticle = $this->repository->findById($id);

        return [
            'success' => true,
            'article' => $updatedArticle
        ];
    }

    /**
     * Publie un article
     * 
     * @param string $id L'ID de l'article
     * @return array Le résultat de la publication
     */
    public function publishArticle(string $id): array {
        $article = $this->repository->findById($id);

        if (!$article) {
            return [
                'success' => false,
                'error' => 'Article non trouvé'
            ];
        }

        $published = $this->repository->publish($id);

        if (!$published) {
            return [
                'success' => false,
                'error' => 'Erreur lors de la publication'
            ];
        }

        $updatedArticle = $this->repository->findById($id);

        return [
            'success' => true,
            'article' => $updatedArticle
        ];
    }

    /**
     * Dépublie un article
     * 
     * @param string $id L'ID de l'article
     * @return array Le résultat de la dépublication
     */
    public function unpublishArticle(string $id): array {
        $article = $this->repository->findById($id);

        if (!$article) {
            return [
                'success' => false,
                'error' => 'Article non trouvé'
            ];
        }

        $unpublished = $this->repository->unpublish($id);

        if (!$unpublished) {
            return [
                'success' => false,
                'error' => 'Erreur lors de la dépublication'
            ];
        }

        $updatedArticle = $this->repository->findById($id);

        return [
            'success' => true,
            'article' => $updatedArticle
        ];
    }

    /**
     * Valide les données de l'article
     * 
     * @param array $data Les données à valider
     * @return array Le résultat de la validation
     */
    private function validate(array $data): array {
        // Vérification de doctorId (accepte aussi doctor_profile_id pour rétro-compatibilité)
        $doctorId = $data['doctorId'] ?? $data['doctor_profile_id'] ?? null;
        if (empty($doctorId)) {
            return [
                'valid' => false,
                'error' => 'Le champ doctorId est obligatoire'
            ];
        }

        // Vérification de title
        if (!isset($data['title']) || empty(trim($data['title']))) {
            return [
                'valid' => false,
                'error' => 'Le champ title est obligatoire'
            ];
        }

        // Vérification de content
        if (!isset($data['content']) || empty(trim($data['content']))) {
            return [
                'valid' => false,
                'error' => 'Le champ content est obligatoire'
            ];
        }

        return ['valid' => true];
    }
}
