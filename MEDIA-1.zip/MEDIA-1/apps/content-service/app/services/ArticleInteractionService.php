<?php

require_once __DIR__ . '/../repositories/ArticleInteractionRepository.php';
require_once __DIR__ . '/../models/ArticleInteraction.php';

/**
 * Service ArticleInteraction
 * Gère la logique métier pour les interactions sur les articles
 */
class ArticleInteractionService {
    private ArticleInteractionRepository $repository;

    public function __construct() {
        $this->repository = new ArticleInteractionRepository();
    }

    /**
     * Ajoute une interaction (like ou view)
     * 
     * @param array $data Les données de l'interaction
     * @return array Le résultat de l'opération
     */
    public function addInteraction(array $data): array {
        // Validation des données
        if (empty($data['articleId'])) {
            return [
                'success' => false,
                'error' => 'articleId est obligatoire'
            ];
        }

        if (strlen($data['articleId']) !== 24) {
            return [
                'success' => false,
                'error' => 'articleId doit être un ObjectId de 24 caractères'
            ];
        }

        if (empty($data['type']) || !in_array($data['type'], ['view', 'like'])) {
            return [
                'success' => false,
                'error' => 'type doit être "view" ou "like"'
            ];
        }

        // userId est requis par le schéma MongoDB
        if (empty($data['userId'])) {
            return [
                'success' => false,
                'error' => 'userId est requis par le schéma MongoDB'
            ];
        }

        if (strlen($data['userId']) !== 24) {
            return [
                'success' => false,
                'error' => 'userId doit être un ObjectId de 24 caractères'
            ];
        }

        // patientId est optionnel
        if (!empty($data['patientId']) && strlen($data['patientId']) !== 24) {
            return [
                'success' => false,
                'error' => 'patientId doit être un ObjectId de 24 caractères'
            ];
        }

        // Pour les likes, vérifier si déjà liké
        if ($data['type'] === 'like') {
            $hasInteracted = $this->repository->hasInteracted(
                $data['articleId'],
                $data['userId'],
                $data['patientId'] ?? null,
                'like'
            );

            if ($hasInteracted) {
                return [
                    'success' => false,
                    'error' => 'Vous avez déjà liké cet article'
                ];
            }
        }

        // Ajouter l'interaction
        try {
            $id = $this->repository->add($data);
            return ['success' => true, 'id' => $id];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error' => 'Erreur lors de l\'ajout de l\'interaction: ' . $e->getMessage()
            ];
        }
    }

    /**
     * Retire une interaction
     * 
     * @param array $data Les données pour identifier l'interaction
     * @return array Le résultat de l'opération
     */
    public function removeInteraction(array $data): array {
        if (empty($data['articleId'])) {
            return [
                'success' => false,
                'error' => 'articleId est obligatoire'
            ];
        }

        if (strlen($data['articleId']) !== 24) {
            return [
                'success' => false,
                'error' => 'articleId doit être un ObjectId de 24 caractères'
            ];
        }

        $type = $data['type'] ?? 'like';

        $removed = $this->repository->remove(
            $data['articleId'],
            $data['userId'] ?? null,
            $data['patientId'] ?? null,
            $type
        );

        if (!$removed) {
            return [
                'success' => false,
                'error' => 'Interaction non trouvée'
            ];
        }

        return ['success' => true];
    }

    /**
     * Compte les interactions par type
     * 
     * @param string $articleId L'ID de l'article
     * @param string $type Le type d'interaction
     * @return array Le résultat avec le nombre
     */
    public function countByType(string $articleId, string $type): array {
        if (empty($articleId)) {
            return [
                'success' => false,
                'error' => 'ID d\'article invalide'
            ];
        }

        $count = $this->repository->countByType($articleId, $type);

        return [
            'success' => true,
            'count' => $count
        ];
    }

    /**
     * Compte toutes les interactions d'un article
     * 
     * @param string $articleId L'ID de l'article
     * @return array Le résultat avec likes et views
     */
    public function countAll(string $articleId): array {
        if (empty($articleId)) {
            return [
                'success' => false,
                'error' => 'ID d\'article invalide'
            ];
        }

        $counts = $this->repository->countAll($articleId);

        return [
            'success' => true,
            'likes' => $counts['likes'],
            'views' => $counts['views']
        ];
    }

    /**
     * Vérifie si une interaction existe
     * 
     * @param array $data Les données pour vérifier
     * @return array Le résultat avec le statut
     */
    public function hasInteracted(array $data): array {
        if (empty($data['articleId'])) {
            return [
                'success' => false,
                'error' => 'articleId est obligatoire'
            ];
        }

        $type = $data['type'] ?? 'like';

        $hasInteracted = $this->repository->hasInteracted(
            $data['articleId'],
            $data['userId'] ?? null,
            $data['patientId'] ?? null,
            $type
        );

        return [
            'success' => true,
            'interacted' => $hasInteracted
        ];
    }
}
