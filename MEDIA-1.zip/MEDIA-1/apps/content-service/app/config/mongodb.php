<?php

require_once __DIR__ . '/../../vendor/autoload.php';

/**
 * Configuration de la connexion à MongoDB
 * Ce fichier charge les variables d'environnement et crée une instance MongoDB\Client
 */

// Charger les variables d'environnement depuis le fichier .env
function loadEnv($path) {
    if (!file_exists($path)) {
        return false;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        if (strpos($line, '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            $value = trim($value, '"\'');
            $_ENV[$name] = $value;
            putenv("$name=$value");
        }
    }
    return true;
}

// Charger le fichier .env
loadEnv(__DIR__ . '/../../.env');

// Singleton pour la connexion MongoDB
static $mongoClient = null;

/**
 * Retourne une instance de connexion MongoDB (singleton)
 * 
 * @return MongoDB\Client Instance du client MongoDB
 */
function getMongoClient(): MongoDB\Client {
    global $mongoClient;
    
    if ($mongoClient === null) {
        set_time_limit(60);
        $mongoUri = $_ENV['MONGO_URI'] ?? 'mongodb://localhost:27017';
        $uriOptions = [
            'connectTimeoutMS' => 5000,
            'socketTimeoutMS' => 10000,
            'serverSelectionTimeoutMS' => 5000,
            'retryWrites' => false,
            'retryReads' => false
        ];
        $driverOptions = [
            'ssl' => true,
            'allow_self_signed' => true
        ];
        $mongoClient = new MongoDB\Client($mongoUri, $uriOptions, $driverOptions);
    }
    
    return $mongoClient;
}

/**
 * Retourne la base de données MongoDB
 * 
 * @return MongoDB\Database Instance de la base de données
 */
function getMongoDatabase(): MongoDB\Database {
    $client = getMongoClient();
    $databaseName = $_ENV['MONGO_DATABASE'] ?? 'med-IA';
    return $client->selectDatabase($databaseName);
}
