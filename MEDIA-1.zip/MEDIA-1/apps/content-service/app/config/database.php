<?php

/**
 * Configuration de la connexion à la base de données MySQL
 * Ce fichier charge les variables d'environnement et crée une instance PDO
 */

// Charger les variables d'environnement depuis le fichier .env
function loadEnv($path) {
    if (!file_exists($path)) {
        return false;
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        // Ignorer les commentaires
        if (strpos(trim($line), '#') === 0) {
            continue;
        }
        
        // Parser la ligne
        if (strpos($line, '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value);
            
            // Supprimer les guillemets si présents
            $value = trim($value, '"\'');
            
            // Définir la variable d'environnement
            $_ENV[$name] = $value;
            putenv("$name=$value");
        }
    }
    return true;
}

// Charger le fichier .env
loadEnv(__DIR__ . '/../../.env');

/**
 * Retourne une instance de connexion PDO à la base de données MySQL
 * 
 * @return PDO Instance de la connexion à la base de données
 * @throws PDOException En cas d'erreur de connexion
 */
function getDatabaseConnection(): PDO {
    // Récupérer les variables d'environnement
    $host = $_ENV['DB_HOST'] ?? '51.91.99.158';
    $port = $_ENV['DB_PORT'] ?? '3306';
    $dbname = $_ENV['DB_NAME'] ?? 'legeekoconsulting_mediataformule';
    $user = $_ENV['DB_USER'] ?? 'legeekoconsulting_metaforuser';
    $password = $_ENV['DB_PASSWORD'] ?? 'fs!TR725Owefdza)';
    $charset = $_ENV['DB_CHARSET'] ?? 'utf8mb4';
    
    // Construire le DSN (Data Source Name) pour MySQL
    $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=$charset";
    
    // Options de connexion PDO
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,    // Lever des exceptions en cas d'erreur
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, // Retourner les résultats sous forme de tableau associatif
        PDO::ATTR_EMULATE_PREPARES => false,              // Utiliser les préparations natives
    ];
    
    try {
        // Créer et retourner l'instance PDO
        $pdo = new PDO($dsn, $user, $password, $options);
        return $pdo;
    } catch (PDOException $e) {
        // Message d'erreur détaillé
        $errorMessage = "Erreur de connexion à la base de données : " . $e->getMessage();
        throw new PDOException($errorMessage);
    }
}
