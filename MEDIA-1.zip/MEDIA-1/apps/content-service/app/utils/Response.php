<?php

/**
 * Classe utilitaire pour les réponses API standardisées
 */
class Response {
    /**
     * Envoie une réponse de succès
     * 
     * @param string $message Message de succès
     * @param mixed $data Données à retourner (null si aucune)
     * @param int $statusCode Code HTTP (par défaut 200)
     */
    public static function success(string $message, $data = null, int $statusCode = 200): void {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode([
            'success' => true,
            'message' => $message,
            'data' => $data,
            'error' => null
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * Envoie une réponse d'erreur
     * 
     * @param string $message Message d'erreur
     * @param string $code Code d'erreur (optionnel)
     * @param string $details Détails de l'erreur (optionnel)
     * @param int $statusCode Code HTTP (par défaut 400)
     */
    public static function error(string $message, ?string $code = null, ?string $details = null, int $statusCode = 400): void {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        
        $error = [];
        if ($code !== null) {
            $error['code'] = $code;
        }
        if ($details !== null) {
            $error['details'] = $details;
        }
        
        echo json_encode([
            'success' => false,
            'message' => $message,
            'data' => null,
            'error' => empty($error) ? null : $error
        ], JSON_UNESCAPED_UNICODE);
    }
}
