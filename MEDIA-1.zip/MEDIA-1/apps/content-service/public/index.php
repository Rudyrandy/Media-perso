<?php

// Point d'entrée de l'API

// Si c'est une requête navigateur pour la racine, servir index.html
if ($_SERVER['REQUEST_URI'] === '/' || $_SERVER['REQUEST_URI'] === '/index.html') {
    require_once __DIR__ . '/index.html';
    exit;
}

// Sinon, router vers l'API
require_once __DIR__ . '/../app/routes/web.php';
