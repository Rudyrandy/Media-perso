<?php

/**
 * Fichier de test pour vérifier la connexion à la base de données MySQL
 * Exécutez ce fichier avec : php test-db.php
 */

// Inclure le fichier de configuration de la base de données
require_once __DIR__ . '/app/config/database.php';

echo "=== Test de connexion à la base de données MySQL ===\n\n";

try {
    // Tenter d'établir la connexion
    echo "1. Tentative de connexion...\n";
    $pdo = getDatabaseConnection();
    echo "   ✓ Connexion réussie !\n\n";
    
    // Afficher les informations de connexion
    echo "2. Informations de connexion :\n";
    echo "   - Hôte : " . $pdo->query('SELECT @@hostname')->fetchColumn() . "\n";
    echo "   - Version MySQL : " . $pdo->query('SELECT VERSION()')->fetchColumn() . "\n";
    echo "   - Base de données : " . $pdo->query('SELECT DATABASE()')->fetchColumn() . "\n\n";
    
    // Tester une requête simple
    echo "3. Test d'une requête simple :\n";
    $result = $pdo->query('SELECT 1 as test');
    $row = $result->fetch();
    echo "   ✓ Résultat de la requête : " . $row['test'] . "\n\n";
    
    echo "=== Tous les tests sont passés avec succès ! ===\n";
    
} catch (PDOException $e) {
    echo "   ✗ Erreur : " . $e->getMessage() . "\n\n";
    echo "=== Vérifiez votre configuration MySQL et le fichier .env ===\n";
    exit(1);
}
