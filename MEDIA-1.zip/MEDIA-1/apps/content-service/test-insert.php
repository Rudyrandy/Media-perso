<?php

require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/app/config/mongodb.php';

echo "MONGO_URI = " . ($_ENV['MONGO_URI'] ?? 'NON DÉFINI') . "\n";
echo "MONGO_DATABASE = " . ($_ENV['MONGO_DATABASE'] ?? 'NON DÉFINI') . "\n\n";

try {
    $db = getMongoDatabase();
    echo "Base: " . $db->getDatabaseName() . "\n\n";

    // Schéma de validation
    $collections = $db->listCollections(['filter' => ['name' => 'articles']]);
    foreach ($collections as $col) {
        $options = $col->getOptions();
        if (isset($options['validator'])) {
            echo "=== SCHÉMA DE VALIDATION ===\n";
            echo json_encode($options['validator'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        } else {
            echo "Pas de schéma de validation sur medai.articles\n";
        }
    }

    // Compter et afficher un doc existant
    $count = $db->articles->countDocuments();
    echo "\nNombre d'articles: $count\n";
    if ($count > 0) {
        $sample = $db->articles->findOne();
        echo "Exemple de document existant :\n";
        echo json_encode($sample->getArrayCopy(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }

    // Vérifier article_likes
    $likesCount = $db->article_likes->countDocuments();
    echo "\nNombre de likes: $likesCount\n";
    if ($likesCount > 0) {
        $sampleLike = $db->article_likes->findOne();
        echo "Exemple de like :\n";
        echo json_encode($sampleLike->getArrayCopy(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }

    // Vérifier article_views
    $viewsCount = $db->article_views->countDocuments();
    echo "\nNombre de vues: $viewsCount\n";
    if ($viewsCount > 0) {
        $sampleView = $db->article_views->findOne();
        echo "Exemple de vue :\n";
        echo json_encode($sampleView->getArrayCopy(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }

} catch (Exception $e) {
    echo "ERREUR: " . $e->getMessage() . "\n";
}
