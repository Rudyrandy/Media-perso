import { createProxyMiddleware } from "http-proxy-middleware";
import services from "../config/services.js";
import { verifyToken } from "../middleware/authMiddleware.js";
import { globalLimiter, authLimiter, aiLimiter, diagnosticLimiter } from "../middleware/rateLimiter.js";
import { createRequire } from 'module';

const require = createRequire(import.meta.url);

export const setupRoutes = (app) => {

   
    
    const authService = services.find(s => s.name === 'auth-service');
    const authProxy = createProxyMiddleware({
        target: 'http://localhost:3001',
        changeOrigin: true,
        pathRewrite: {
            [`^${authService.prefix}`]: '/auth',
        },
        onError: (err, req, res) => {
            res.status(504).json({
                message: "Le service d'authentification est temporairement indisponible(Service Down).",
                code: "AUTH_SERVICE_OFFLINE"
            });
        }
    });

   

    const searchService = services.find(s => s.name === 'search-service');
    
    const searchProxy = createProxyMiddleware({
        target: searchService.url,
        changeOrigin: true,
        pathRewrite: {
            '^/api/search': '/api/doctors',
        },
        onError: (err, req, res) => {
            res.status(504).json({
                message: "Le service de recherche est indisponible.",
                code: "SEARCH_SERVICE_OFFLINE"
            });
        }
    });

    const doctorsProxy = createProxyMiddleware({
        target: searchService.url,
        changeOrigin: true,
        pathRewrite: {
            '^/api/search/doctors': '/api/doctors',
        },
        onError: (err, req, res) => {
            res.status(504).json({
                message: "Le service doctors est indisponible.",
                code: "DOCTORS_SERVICE_OFFLINE"
            });
        }
    });

    const recommendationsProxy = createProxyMiddleware({
        target: searchService.url,
        changeOrigin: true,
        pathRewrite: {
            '^/api/search/recommendations': '/api/recommendations',
       },
        onError: (err, req, res) => {
            res.status(504).json({
                message: "Le service recommendations est indisponible.",
                code: "RECOMMENDATIONS_SERVICE_OFFLINE"
            });
        }
    });

    

    const reportService = services.find(s => s.name === 'report-service');
    const reportProxy = createProxyMiddleware({
        target: reportService.url,
        changeOrigin: true,
        pathRewrite: {
            [`^${reportService.prefix}`]: '',
        },
        onError: (err, req, res) => {
            res.status(504).json({
                message: "Le service de rapports est indisponible.",
                code: "REPORT_SERVICE_OFFLINE"
            });
        }
    });

   
    const aiService = services.find(s => s.name === 'ai-service');
    const aiProxy = createProxyMiddleware({
        target: aiService.url,
        changeOrigin: true,
        pathRewrite: {
            [`^${aiService.prefix}`]: '/ia',
        },
        onError: (err, req, res) => {
            res.status(504).json({
                message: "Le service IA est indisponible.",
                code: "AI_SERVICE_OFFLINE"
            });
        }
    });

    

    const contentService = services.find(s => s.name === 'content-service');
    const contentProxy = createProxyMiddleware({
        target: contentService.url,
        changeOrigin: true,
        pathRewrite: {
            [`^${contentService.prefix}`]: '',
        },
        onError: (err, req, res) => {
            
            res.status(504).json({
                message: "Le service de contenu est indisponible.",
                code: "CONTENT_SERVICE_OFFLINE"
            });
        }
    });

    

    const diagnosticService = services.find(s => s.name === 'diagnostic-service');
    const diagnosticProxy = createProxyMiddleware({
        target: diagnosticService.url,
        changeOrigin: true,        
       pathRewrite: {
   '^/api/diagnostic': ' ',
},
        onError: (err, req, res) => {
            res.status(504).json({
                message: "Le service de diagnostic est indisponible.",
                code: "DIAGNOSTIC_SERVICE_OFFLINE"
            });
        }
    });


    app.use('/api', globalLimiter);

    // Routes Authentification
    app.use('/api/auth/register', authLimiter, authProxy);
    app.use('/api/auth/login', authLimiter, authProxy);
    app.use('/api/auth/logout', authProxy);
    app.use('/api/auth/verify', verifyToken, authProxy);

    // Routes Recherche / Médecins
    app.use('/api/search/doctors', globalLimiter, doctorsProxy); 
    app.use('/api/search/recommendations', verifyToken, recommendationsProxy); 
    app.use('/api/search', globalLimiter, searchProxy);

    // Autres Microservices
    app.use(reportService.prefix, verifyToken, reportProxy);
    app.use(aiService.prefix, verifyToken, aiLimiter, aiProxy);
    app.use(contentService.prefix, contentProxy);
    app.use(diagnosticService.prefix, diagnosticLimiter, diagnosticProxy);

};