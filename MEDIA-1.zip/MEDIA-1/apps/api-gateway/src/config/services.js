const services = [
    {
        name: 'auth-service',
        protocol: 'http',
        host: 'localhost',
        port: '3001',
        url: 'http://localhost:3001',
        prefix: '/api/auth'
    },

    {
        name: 'search-service',
        url: 'http://192.168.1.204:3000',
        prefix: '/api/search'
    },

    {
        name: 'report-service',
        url: 'http://localhost:8000',
        prefix: '/api/reports'
    },

    {
        name: 'ai-service',
        url: 'http://localhost:5678',
        prefix: '/api/ai'
    },

    {
        name: "content-service",
        prefix: "/api/content",
        url: "http://localhost:8000"
    },

    {
        name: "diagnostic-service",
        prefix: "/api/diagnostic",
        url: "http://api.medicalai.space"
    }

];

export default services;