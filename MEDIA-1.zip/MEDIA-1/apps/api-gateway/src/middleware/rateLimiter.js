import rateLimit from "express-rate-limit";

export const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: {
        error: "Trop de requetes",
        message: "Vous avez depasse la limite autorisee. Reessayer dans 15 minutes."
    },
    standardHeaders: true,
    legacyHeaders: false,
});

export const authLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 5,
    message: {
        error: "Alerte sécurité",
        message: "Trop de tentatives de connexion. Compte bloqué temporairement pour cette IP"
    },
     standardHeaders: true,
    legacyHeaders: false,
});

export const aiLimiter = rateLimit({
    windowMs: 60* 1000,
    max: 5,
    message: "Trop de requetes ves le service IA"
});

export const diagnosticLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 10,
    message: "Trop de requetes vers le service diagnostic"
});