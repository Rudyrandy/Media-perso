export const errorHandler = (err, req, res, next) => {
    console.error(err.stack);

    const statusCode = err.status || 500;
    res.status(statusCode).json({
        error: true,
        status: statusCode,
        message: err.message || "Une erreur interne est survenue sur la Gateway",
        path: req.url
    });
};