import express from "express";
import { errorHandler } from "./middleware/errorHandler.js";
import helmet from "helmet";
import cors from "cors";
import morgan from "morgan";
import { setupRoutes } from "./routes/proxy.js";

const app = express();

app.use(morgan('dev'));

app.use(helmet());
app.use(cors({
    origin: "http://localhost:3000", // Remplacer par l'URL de ton front (React/Mobile)
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
}));

setupRoutes(app);

app.use(express.json());

app.get("/", (req, res) => {
    res.send("API Gateway running...");



app.use(errorHandler);
});

export default app;