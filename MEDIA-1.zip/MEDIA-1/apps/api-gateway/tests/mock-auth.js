import express from "express";
const app = express();
app.use(express.json());

app.post('/auth/register', (req, res) => {
    console.log("Donnees recus de la Gateway :", req.body);
    res.json({message: "Succes !", data: req.body});
});

app.listen(3001, () => console.log("Service Auth simule sur le port 3001"));