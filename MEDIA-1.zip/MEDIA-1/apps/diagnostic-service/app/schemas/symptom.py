"""
Pydantic schemas for symptoms.

This module defines the input and output schemas for symptom operations.
Adapted for MongoDB with ObjectId support.
"""

from datetime import date, datetime
from typing import Optional, List, Literal
from pydantic import BaseModel, ConfigDict, field_validator
from bson import ObjectId


class MongoBaseModel(BaseModel):
    """
    Base model with MongoDB ObjectId encoder.
    
    This model provides automatic conversion of ObjectId to string
    for JSON serialization.
    """
    model_config = ConfigDict(
        from_attributes=True,
        json_encoders={ObjectId: str}
    )


class SymptomResponse(MongoBaseModel):
    """
    Schema for symptom response (MongoDB compatible).
    
    Attributes:
        id: Symptom ID (ObjectId as string)
        code: Symptom code
        label: Symptom label
        description: Symptom description
        phaseCode: Code of the diagnostic phase
        inputType: Input type for the symptom
        choices: Available choices for the symptom (if inputType is 'choice')
        isRedFlag: Whether the symptom is a red flag
        severityImpact: Severity impact level
        tags: Tags associated with the symptom
        active: Whether the symptom is active
        createdAt: Timestamp when the symptom was created
        updatedAt: Timestamp when the symptom was last updated
    """
    id: str  # ObjectId as string
    code: str
    label: str
    description: Optional[str] = None
    phaseCode: str
    inputType: Optional[str] = None
    choices: Optional[List[str]] = None
    isRedFlag: bool = False
    severityImpact: Optional[str] = None
    tags: Optional[List[str]] = None
    active: bool
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None


class SymptomEntryItemCreate(BaseModel):
    """
    Schema for creating a single symptom entry.
    
    Accepts the full symptom structure and extracts relevant fields for the entry.
    
    Attributes:
        id: Symptom ID (ObjectId as string) - REQUIRED
        code: Symptom code
        label: Symptom label
        description: Symptom description
        phaseCode: Code of the diagnostic phase
        inputType: Input type for the symptom (enum)
        choices: Available choices for the symptom (if inputType is 'choice')
        isRedFlag: Whether the symptom is a red flag
        severityImpact: Severity impact level (enum)
        tags: Tags associated with the symptom
        active: Whether the symptom is active
        createdAt: Timestamp when the symptom was created
        updatedAt: Timestamp when the symptom was last updated
        present: Whether the symptom is present
        intensity: Intensity of the symptom
        duration_value: Duration value
        duration_unit: Duration unit (e.g., days, hours)
        started_on: Date when the symptom started
        comment: Additional comments
    """
    id: str
    code: str
    label: str
    description: Optional[str] = None
    phaseCode: str
    inputType: Literal["boolean", "number", "scale", "text", "choice", "multi_choice"]
    choices: Optional[List[str]] = None
    isRedFlag: bool = False
    severityImpact: Literal["none", "low", "medium", "high", "critical"]
    tags: Optional[List[str]] = None
    active: bool
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
    present: bool = True
    intensity: Optional[str] = None
    duration_value: Optional[int] = None
    duration_unit: Optional[str] = None
    started_on: Optional[date] = None
    comment: Optional[str] = None
    
    @field_validator('duration_value')
    @classmethod
    def duration_value_must_be_positive(cls, v: Optional[int]) -> Optional[int]:
        if v is not None and v < 0:
            raise ValueError('duration_value must be greater than or equal to 0')
        return v
    
    model_config = ConfigDict(from_attributes=True)


class SymptomEntryBulkCreate(BaseModel):
    """
    Schema for bulk creating symptom entries.
    
    Attributes:
        entries: List of symptom entries to create
    """
    entries: List[SymptomEntryItemCreate]
    
    model_config = ConfigDict(from_attributes=True)


class SessionSymptomItem(BaseModel):
    """
    Schema for a single symptom in the session symptoms collection.
    
    Attributes:
        symptomId: Symptom ID (ObjectId as string)
        symptomCode: Code of the symptom
        label: Label of the symptom
        phaseCode: Code of the diagnostic phase
        inputType: Input type for the symptom
        value: Value object containing present, intensity, duration_value, duration_unit
        unit: Duration unit
        isRedFlag: Whether the symptom is a red flag
        severityImpact: Severity impact level
    """
    symptomId: str
    symptomCode: str
    label: str
    phaseCode: str
    inputType: Optional[str] = None
    value: dict
    unit: Optional[str] = None
    isRedFlag: bool = False
    severityImpact: Optional[str] = None


class SessionSymptomsResponse(MongoBaseModel):
    """
    Schema for session symptoms response (diagnostic_session_symptoms collection).
    
    Attributes:
        id: Document ID (ObjectId as string)
        diagnosticSessionId: ID of the diagnostic session (ObjectId as string)
        patientId: ID of the patient (ObjectId as string)
        symptoms: List of symptoms
        createdAt: Timestamp when the document was created
        updatedAt: Timestamp when the document was last updated
    """
    id: str
    diagnosticSessionId: str
    patientId: str
    symptoms: List[SessionSymptomItem]
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
