"""
Pydantic schemas for diagnostic sessions.

This module defines the input and output schemas for diagnostic session operations.
Adapted for MongoDB with ObjectId support.
"""

from datetime import datetime
from typing import Optional, List, Literal
from pydantic import BaseModel, ConfigDict, field_validator
from bson import ObjectId


class MongoBaseModel(BaseModel):
    """
    Base model with MongoDB ObjectId encoder.
    
    This model provides automatic conversion of ObjectId to string
    for JSON serialization.
    """
    model_config = ConfigDict(
        from_attributes=True,
        json_encoders={ObjectId: str}
    )


class DiagnosticSessionCreate(BaseModel):
    """
    Schema for creating a new diagnostic session.
    
    Attributes:
        patient_profile_id: ID of the patient profile starting the session
    """
    patient_profile_id: str  # ObjectId as string
    
    model_config = ConfigDict(from_attributes=True)


class EmergencyData(BaseModel):
    """
    Schema for emergency data.
    """
    detected: bool = False
    level: Optional[str] = None
    message: Optional[str] = None
    phone_number: Optional[str] = None


class ResultData(BaseModel):
    """
    Schema for diagnostic result data.
    """
    risk_level: Optional[str] = None
    status: Optional[str] = None
    score: Optional[int] = None
    summary: Optional[str] = None
    next_action: Optional[str] = None
    recommended_specialties: Optional[List[str]] = None
    triggered_rules: Optional[List[str]] = None
    generated_at: Optional[datetime] = None


class AIData(BaseModel):
    """
    Schema for AI data.
    """
    explanation_id: Optional[str] = None
    thread_id: Optional[str] = None


class DiagnosticSessionResponse(MongoBaseModel):
    """
    Schema for diagnostic session response (MongoDB compatible).
    
    Attributes:
        id: Session ID (ObjectId as string)
        patientId: ID of the patient profile
        userId: ID of the user
        status: Current status of the session
        currentPhaseCode: Current phase code
        entries: List of symptom entries
        result: Diagnostic result
        emergency: Emergency data
        ai: AI data
        createdAt: Timestamp when the session was created
        updatedAt: Timestamp when the session was last updated
        completedAt: Timestamp when the session was completed
    """
    id: str  # ObjectId as string
    patientId: str  # ObjectId as string
    userId: Optional[str] = None  # ObjectId as string
    status: str
    currentPhaseCode: Optional[str] = None
    entries: Optional[List[dict]] = None
    result: Optional[dict] = None
    emergency: Optional[dict] = None
    ai: Optional[dict] = None
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
    completedAt: Optional[datetime] = None


class DiagnosticPhaseResponse(MongoBaseModel):
    """
    Schema for diagnostic phase response (MongoDB compatible).
    
    Attributes:
        id: Phase ID (ObjectId as string)
        code: Phase code
        label: Phase label
        description: Phase description
        order: Order number for sorting
        active: Whether the phase is active
    """
    id: str  # ObjectId as string
    code: str
    label: str
    description: Optional[str] = None
    order: int
    active: bool


class DiagnosticResultResponse(MongoBaseModel):
    """
    Schema for diagnostic evaluation result (MongoDB compatible).
    
    This schema is deprecated and replaced by ResultResponse for the results collection.
    """
    id: str
    session_id: str
    patient_id: str
    diagnostic_code: Optional[str] = None
    diagnostic_label: Optional[str] = None
    confidence_score: Optional[float] = None
    recommended_action: Optional[str] = None
    additional_notes: Optional[str] = None
    evaluated_at: Optional[datetime] = None


class MatchedRule(BaseModel):
    """
    Schema for a matched rule in the results collection.
    
    Attributes:
        ruleCode: Code of the triggered rule
        type: Type of rule (danger, score, orientation, mapping)
        score: Score contributed by this rule
        priority: Priority of the triggered rule
    """
    ruleCode: str
    type: Literal["danger", "score", "orientation", "mapping"]
    score: Optional[int] = None
    priority: Optional[int] = None


class ResultSymptomItem(BaseModel):
    """
    Schema for a symptom in the results collection.
    
    Attributes:
        symptomCode: Code of the symptom
        label: Display name of the symptom
        value: Value entered by the patient
        inputType: Type of response
        unit: Unit if necessary
    """
    symptomCode: str
    label: str
    value: dict
    inputType: Optional[Literal["boolean", "number", "scale", "text", "choice", "multi_choice"]] = None
    unit: Optional[str] = None


class ResultResponse(MongoBaseModel):
    """
    Schema for diagnostic result (results collection).
    
    Attributes:
        id: Document ID (ObjectId as string)
        patientId: ID of the patient (ObjectId as string)
        userId: Optional ID of the user linked to the patient
        doctorId: Optional ID of the doctor associated with the result
        symptoms: List of symptoms entered by the patient
        matchedRules: List of triggered business rules
        totalScore: Total calculated score
        diagnosticCode: Code of the final diagnostic
        diagnosticLabel: Display name of the diagnostic
        diagnosticLevel: Level of the diagnostic
        severity: Technical calculated severity
        riskLevel: Business risk level
        businessLabel: Business label of the result
        status: Recommended action or status
        specialtyCode: Recommended medical specialty
        message: Final message to display to the user
        source: Source of the result (automatic or doctor_validation)
        createdAt: Timestamp when the result was created
        updatedAt: Timestamp when the result was last updated
    """
    id: str
    patientId: str
    userId: Optional[str] = None
    doctorId: Optional[str] = None
    symptoms: List[ResultSymptomItem]
    matchedRules: List[MatchedRule]
    totalScore: Optional[int] = None
    diagnosticCode: str
    diagnosticLabel: str
    diagnosticLevel: Optional[Literal["leger", "moyen", "grave"]] = None
    severity: Optional[Literal["low", "medium", "high", "critical"]] = None
    riskLevel: Literal["faible", "modere", "eleve", "urgent"]
    businessLabel: str
    status: Literal["RAS", "Surveillance", "Consulter", "Urgence"]
    specialtyCode: Optional[str] = None
    message: str
    source: Optional[Literal["automatic", "doctor_validation"]] = None
    createdAt: Optional[datetime] = None
    updatedAt: Optional[datetime] = None
