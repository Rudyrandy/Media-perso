"""
Standardized API response schemas.

This module defines the unified response format for all API endpoints.
"""

from typing import Optional, Any, Generic, TypeVar
from pydantic import BaseModel, ConfigDict
from bson import ObjectId
import json

T = TypeVar('T')


class ErrorDetail(BaseModel):
    """
    Schema for error details in the response.
    
    Attributes:
        code: Error code for programmatic handling
        details: Human-readable error details
    """
    code: str
    details: str


class ApiResponse(BaseModel, Generic[T]):
    """
    Standardized API response format.
    
    This schema provides a consistent response structure for all endpoints.
    
    Attributes:
        success: Whether the request was successful
        message: Human-readable message describing the result
        data: Response data (present on success)
        error: Error details (present on failure)
    """
    success: bool
    message: str
    data: Optional[T] = None
    error: Optional[ErrorDetail] = None
    
    model_config = ConfigDict(
        json_schema_extra={
            "examples": [
                {
                    "success": True,
                    "message": "Operation completed successfully",
                    "data": {"id": "123"},
                    "error": None
                },
                {
                    "success": False,
                    "message": "Operation failed",
                    "data": None,
                    "error": {
                        "code": "ERR_001",
                        "details": "Detailed error message"
                    }
                }
            ]
        }
    )


class ObjectIdEncoder(json.JSONEncoder):
    """Custom JSON encoder to handle ObjectId serialization."""
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        return super().default(obj)


def serialize_objectids(data: Any) -> Any:
    """
    Recursively convert ObjectIds to strings in a data structure.
    
    Args:
        data: Data structure to process
        
    Returns:
        Data structure with ObjectIds converted to strings
    """
    if isinstance(data, dict):
        return {k: serialize_objectids(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [serialize_objectids(item) for item in data]
    elif isinstance(data, ObjectId):
        return str(data)
    else:
        return data


def create_success_response(message: str, data: Any = None) -> dict:
    """
    Create a success response in the standardized format.
    
    Args:
        message: Success message
        data: Response data (optional)
        
    Returns:
        dict: Formatted success response
    """
    serialized_data = serialize_objectids(data)
    return {
        "success": True,
        "message": message,
        "data": serialized_data,
        "error": None
    }


def create_error_response(message: str, error_code: str, error_details: str) -> dict:
    """
    Create an error response in the standardized format.
    
    Args:
        message: Error message
        error_code: Error code for programmatic handling
        error_details: Detailed error information
        
    Returns:
        dict: Formatted error response
    """
    return {
        "success": False,
        "message": message,
        "data": None,
        "error": {
            "code": error_code,
            "details": error_details
        }
    }
