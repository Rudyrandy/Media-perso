"""
Business logic for symptoms.

This module contains the service layer for symptom operations using MongoDB.
Entries are now embedded in the diagnostic_phase document.
"""

from datetime import datetime
from bson import ObjectId
from app.repositories import diagnostic_repo, symptom_repo
from app.schemas.symptom import SymptomEntryItemCreate
from app.core.database import get_mongo_client
from app.core.config import settings


async def list_symptoms_by_phase(phase_id: str) -> list[dict]:
    """
    Get all active symptoms for a given phase by phase ID.
    
    This function validates that the phase exists and retrieves all
    active symptoms for that phase.
    
    Args:
        phase_id: ID of the phase to get symptoms for (ObjectId as string)
        
    Returns:
        list[dict]: List of active symptom documents for the phase
        
    Raises:
        ValueError: If phase_id is invalid
        ValueError: If the phase does not exist
    """
    if not phase_id:
        raise ValueError(f"Invalid phase_id: {phase_id}. Must be provided.")
    
    # Find phase by ID
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    try:
        phase = await db.diagnostic_phases.find_one({"_id": ObjectId(phase_id)})
        if not phase:
            raise ValueError(f"Phase with id {phase_id} not found.")
    except:
        raise ValueError(f"Invalid phase_id format: {phase_id}")
    
    return await symptom_repo.get_active_symptoms_by_phase(phase_id)


async def save_session_symptoms(session_id: str, entries: list[SymptomEntryItemCreate]) -> dict:
    """
    Save symptom entries for a diagnostic session.
    
    This function validates the session and each entry, then saves the symptoms
    to the diagnostic_session_symptoms collection.
    
    Args:
        session_id: ID of the diagnostic session (ObjectId as string)
        entries: List of symptom entries to create
        
    Returns:
        dict: The saved document from diagnostic_session_symptoms collection
        
    Raises:
        ValueError: If session_id is invalid or session is not found
        ValueError: If entries list is empty
        ValueError: If session is already completed
    """
    if not session_id:
        raise ValueError(f"Invalid session_id: {session_id}. Must be provided.")
    
    session = await diagnostic_repo.get_session_by_id(session_id)
    if not session:
        raise ValueError(f"Session with id {session_id} not found.")
    
    if session.get("status") == "completed":
        raise ValueError("Cette session de diagnostic est déjà terminée et ne peut plus être modifiée.")
    
    if not entries:
        raise ValueError("Entries list cannot be empty.")
    
    # Get patient_id from session
    patient_id = session.get("patientId")
    if not patient_id:
        raise ValueError("Session does not have a patientId.")
    
    # Convert entries to the new collection structure
    symptoms_list = []
    for entry in entries:
        symptom_data = {
            "symptomId": ObjectId(entry.id),
            "symptomCode": entry.code,
            "label": entry.label,
            "phaseCode": entry.phaseCode,
            "inputType": entry.inputType,
            "value": {
                "present": entry.present,
                "intensity": entry.intensity,
                "duration_value": entry.duration_value,
                "duration_unit": entry.duration_unit
            },
            "unit": entry.duration_unit,
            "isRedFlag": entry.isRedFlag,
            "severityImpact": entry.severityImpact
        }
        symptoms_list.append(symptom_data)
    
    # Save to the new collection
    result = await symptom_repo.save_session_symptoms_to_collection(session_id, patient_id, symptoms_list)
    if not result:
        raise ValueError("Failed to save session symptoms.")
    
    return result


async def get_session_symptoms(session_id: str) -> dict:
    """
    Get all symptom entries for a diagnostic session.
    
    This function retrieves all submitted symptom entries for a session
    from the diagnostic_session_symptoms collection.
    
    Args:
        session_id: ID of the diagnostic session (ObjectId as string)
        
    Returns:
        dict: The document with symptoms from diagnostic_session_symptoms collection
        
    Raises:
        ValueError: If session_id is invalid
        ValueError: If the session does not exist
    """
    if not session_id:
        raise ValueError(f"Invalid session_id: {session_id}. Must be provided.")
    
    return await symptom_repo.get_session_symptoms_from_collection(session_id)
