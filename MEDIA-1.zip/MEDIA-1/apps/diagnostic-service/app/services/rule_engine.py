"""
Rule engine for diagnostic evaluation.

This module contains the logic for evaluating diagnostic sessions
and determining risk levels based on symptom entries.
"""

from typing import List, Dict
from app.models.symptom import SymptomEntry, Symptom


def evaluate_session(entries: List[SymptomEntry], symptoms_map: Dict[int, Symptom]) -> Dict:
    """
    Evaluate a diagnostic session based on symptom entries.
    
    This MVP implementation uses simple logic:
    - If any present symptom has is_danger = True -> urgent
    - Otherwise -> low risk
    - Score = number of present symptoms
    - Summary = symptom count
    
    Args:
        entries: List of symptom entries for the session
        symptoms_map: Dictionary mapping symptom_id to Symptom objects
        
    Returns:
        Dict: Evaluation result with risk_level, status_label, score, summary
    """
    # Identify present symptoms
    present_entries = [entry for entry in entries if entry.present]
    
    if not present_entries:
        return {
            "risk_level": "faible",
            "status_label": "RAS",
            "score": 0,
            "summary": "Aucun symptôme détecté"
        }
    
    # Check for dangerous symptoms
    has_danger = False
    for entry in present_entries:
        symptom = symptoms_map.get(entry.symptom_id)
        if symptom and symptom.is_danger:
            has_danger = True
            break
    
    # Determine risk level
    if has_danger:
        risk_level = "urgent"
        status_label = "Urgence"
    else:
        risk_level = "faible"
        status_label = "RAS"
    
    # Calculate score
    score = len(present_entries)
    
    # Generate summary
    summary = f"Nombre de symptômes détectés : {score}"
    
    return {
        "risk_level": risk_level,
        "status_label": status_label,
        "score": score,
        "summary": summary
    }
