"""
Business logic for diagnostic sessions.

This module contains the service layer for diagnostic session operations using MongoDB.
"""

from datetime import datetime
from app.repositories import diagnostic_repo, symptom_repo, result_repo
from app.services import rule_engine


async def start_diagnostic(patient_profile_id: str) -> dict:
    """
    Start a new diagnostic session for a patient.
    
    This function validates the patient profile ID and creates a new
    diagnostic session with the initial status set to 'started'.
    
    Args:
        patient_profile_id: ID of the patient profile starting the session (ObjectId as string)
        
    Returns:
        dict: The newly created diagnostic session document
        
    Raises:
        ValueError: If patient_profile_id is invalid (<= 0)
    """
    if not patient_profile_id:
        raise ValueError(f"Invalid patient_profile_id: {patient_profile_id}. Must be provided.")
    
    return await diagnostic_repo.create_session(patient_profile_id)


async def list_active_phases() -> list[dict]:
    """
    Get all active diagnostic phases.
    
    This function retrieves all active diagnostic phases ordered by order_no.
    
    Returns:
        list[dict]: List of active phase documents sorted by order_no
    """
    return await diagnostic_repo.get_active_phases()


async def evaluate_diagnostic(session_id: str) -> dict:
    """
    Evaluate a diagnostic session using the rule engine.
    
    This function retrieves the session and its symptom entries, then
    applies the rule engine to generate a diagnostic evaluation.
    The result is saved to the results collection.
    
    Args:
        session_id: ID of the diagnostic session to evaluate (ObjectId as string)
        
    Returns:
        dict: The saved diagnostic result document from the results collection
        
    Raises:
        ValueError: If session_id is invalid (<= 0)
        ValueError: If the session does not exist
        ValueError: If the session has no symptom entries to evaluate
        
    Note:
        The rule engine analyzes symptoms against business rules to determine
        risk level, potential diagnoses, and recommended actions.
    """
    if not session_id:
        raise ValueError(f"Invalid session_id: {session_id}. Must be provided.")
    
    session = await diagnostic_repo.get_session_by_id(session_id)
    if not session:
        raise ValueError(f"Session with id {session_id} not found.")
    
    # Get symptoms from the diagnostic_session_symptoms collection
    from app.repositories.symptom_repo import get_session_symptoms_from_collection
    session_symptoms = await get_session_symptoms_from_collection(session_id)
    
    if not session_symptoms or not session_symptoms.get("symptoms"):
        raise ValueError(f"Session with id {session_id} has no symptom entries to evaluate.")
    
    patient_id = session.get("patientId")
    if not patient_id:
        raise ValueError("Session does not have a patientId.")
    
    # TODO: Implement actual rule engine evaluation
    # For now, create a placeholder result
    symptoms_list = session_symptoms.get("symptoms", [])
    
    result_data = {
        "symptoms": [
            {
                "symptomCode": s.get("symptomCode"),
                "label": s.get("label"),
                "value": s.get("value"),
                "inputType": s.get("inputType"),
                "unit": s.get("unit")
            }
            for s in symptoms_list
        ],
        "matchedRules": [],
        "totalScore": 0,
        "diagnosticCode": "UNKNOWN",
        "diagnosticLabel": "Diagnostic en cours",
        "diagnosticLevel": "leger",
        "severity": "low",
        "riskLevel": "faible",
        "businessLabel": "Cas stable",
        "status": "RAS",
        "message": "Évaluation en attente de validation",
        "source": "automatic"
    }
    
    result = await diagnostic_repo.save_diagnostic_result(patient_id, result_data)
    
    # Update session with result reference
    await diagnostic_repo.update_session_status(session_id, "in_progress")
    
    return result


async def finish_diagnostic(session_id: str) -> dict:
    """
    Finish a diagnostic session by marking it as completed.
    
    This function validates that the session exists and is not already completed,
    then updates the session to completed status.
    
    Args:
        session_id: ID of the diagnostic session to finish (ObjectId as string)
        
    Returns:
        dict: The updated session document
        
    Raises:
        ValueError: If session_id is invalid (<= 0)
        ValueError: If the session does not exist
        ValueError: If the session is already completed
        
    Note:
        Once a session is completed, it should not accept further modifications.
        Other endpoints (e.g., symptom submission, evaluation) should respect this functional lock.
    """
    if not session_id:
        raise ValueError(f"Invalid session_id: {session_id}. Must be provided.")
    
    session = await diagnostic_repo.get_session_by_id(session_id)
    if not session:
        raise ValueError(f"Session with id {session_id} not found.")
    
    if session.get("status") == "completed":
        raise ValueError("Cette session de diagnostic est déjà terminée et ne peut plus être modifiée.")
    
    return await diagnostic_repo.update_session_to_completed(session_id)
