"""
SQLAlchemy models for diagnostic phases and sessions.

This module defines the database models for diagnostic phases and sessions,
which are core entities in the diagnostic workflow.
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class DiagnosticPhase(Base):
    """
    Model representing a phase in the diagnostic process.
    
    A diagnostic session progresses through multiple phases, each containing
    specific symptoms to evaluate.
    """
    __tablename__ = "diagnostic_phases"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(40), nullable=False, unique=True, index=True)
    name = Column(String(120), nullable=False)
    order_no = Column(Integer, nullable=False)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    symptoms = relationship("Symptom", back_populates="phase", cascade="all, delete-orphan")
    sessions_as_current = relationship(
        "DiagnosticSession",
        back_populates="current_phase",
        foreign_keys="DiagnosticSession.current_phase_id"
    )
    
    def __repr__(self):
        return f"<DiagnosticPhase(id={self.id}, code='{self.code}', name='{self.name}')>"


class DiagnosticSession(Base):
    """
    Model representing a diagnostic session for a patient.
    
    A session tracks the progress of a patient through the diagnostic phases,
    from start to completion.
    """
    __tablename__ = "diagnostic_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    patient_profile_id = Column(Integer, nullable=False, index=True)
    started_at = Column(DateTime, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    status = Column(String(20), nullable=False, default="in_progress")
    current_phase_id = Column(Integer, ForeignKey("diagnostic_phases.id", ondelete="SET NULL"), nullable=True, index=True)
    created_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=True)
    
    # Relationships
    current_phase = relationship("DiagnosticPhase", foreign_keys=[current_phase_id])
    symptom_entries = relationship("SymptomEntry", back_populates="session", cascade="all, delete-orphan")
    results = relationship("DiagnosticResult", foreign_keys="DiagnosticResult.session_id", back_populates="session", cascade="all, delete-orphan")
    emergency_alerts = relationship("EmergencyAlertLog", back_populates="session", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index("idx_diagnostic_sessions_patient_profile_id", "patient_profile_id"),
        Index("idx_diagnostic_sessions_current_phase_id", "current_phase_id"),
    )
    
    def __repr__(self):
        return f"<DiagnosticSession(id={self.id}, patient_profile_id={self.patient_profile_id}, status='{self.status}')>"
