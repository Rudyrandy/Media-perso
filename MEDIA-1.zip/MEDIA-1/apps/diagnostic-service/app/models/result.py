"""
SQLAlchemy models for diagnostic results.

This module defines the database model for diagnostic results,
which store the outcome of a diagnostic session including risk assessment.
"""

from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class DiagnosticResult(Base):
    """
    Model representing the result of a diagnostic session.
    
    A result contains the risk assessment, status, recommendations,
    and summary generated from evaluating the patient's symptoms.
    """
    __tablename__ = "diagnostic_results"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("diagnostic_sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    is_final = Column(Boolean, nullable=False, default=False)
    session_id_final = Column(Integer, ForeignKey("diagnostic_sessions.id", ondelete="SET NULL"), nullable=True, unique=True, index=True)
    risk_level = Column(String(20), nullable=False)
    status_label = Column(String(40), nullable=False)
    next_action = Column(String(120), nullable=True)
    disclaimer = Column(String(255), nullable=True)
    score = Column(Integer, nullable=True)
    summary = Column(Text, nullable=True)
    created_at = Column(DateTime, nullable=True)
    
    # Relationships
    session = relationship("DiagnosticSession", foreign_keys=[session_id], back_populates="results")
    session_final = relationship("DiagnosticSession", foreign_keys=[session_id_final])
    triggered_rules = relationship("TriggeredRule", back_populates="result", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index("idx_diagnostic_results_session_id", "session_id"),
    )
    
    def __repr__(self):
        return f"<DiagnosticResult(id={self.id}, session_id={self.session_id}, risk_level='{self.risk_level}', status_label='{self.status_label}')>"
