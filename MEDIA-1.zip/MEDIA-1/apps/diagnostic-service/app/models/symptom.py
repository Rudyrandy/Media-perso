"""
SQLAlchemy models for symptoms and symptom entries.

This module defines the database models for symptoms (the questions/conditions)
and symptom entries (patient responses during a session).
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, Date, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class Symptom(Base):
    """
    Model representing a symptom or condition to be evaluated.
    
    Symptoms are organized by diagnostic phase and contain metadata about
    when and how they should be evaluated.
    """
    __tablename__ = "symptoms"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(60), nullable=False, unique=True, index=True)
    name = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    phase_id = Column(Integer, ForeignKey("diagnostic_phases.id", ondelete="CASCADE"), nullable=False, index=True)
    category = Column(String(100), nullable=True)
    is_danger = Column(Boolean, default=False)
    sex_applicable = Column(String(10), nullable=True)
    age_min = Column(Integer, nullable=True)
    age_max = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    phase = relationship("DiagnosticPhase", back_populates="symptoms")
    entries = relationship("SymptomEntry", back_populates="symptom", cascade="all, delete-orphan")
    rules = relationship("Rule", back_populates="symptom", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index("idx_symptoms_phase_id", "phase_id"),
    )
    
    def __repr__(self):
        return f"<Symptom(id={self.id}, code='{self.code}', name='{self.name}')>"


class SymptomEntry(Base):
    """
    Model representing a patient's response to a symptom during a session.
    
    Each entry records whether a symptom is present, its intensity, duration,
    and any additional comments from the patient.
    """
    __tablename__ = "symptom_entries"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("diagnostic_sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    symptom_id = Column(Integer, ForeignKey("symptoms.id", ondelete="CASCADE"), nullable=False, index=True)
    phase_id = Column(Integer, ForeignKey("diagnostic_phases.id", ondelete="CASCADE"), nullable=False, index=True)
    present = Column(Boolean, nullable=False, default=True)
    intensity = Column(String(20), nullable=True)
    duration_value = Column(Integer, nullable=True)
    duration_unit = Column(String(10), nullable=True)
    started_on = Column(Date, nullable=True)
    comment = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=True)
    
    # Relationships
    session = relationship("DiagnosticSession", back_populates="symptom_entries")
    symptom = relationship("Symptom", back_populates="entries")
    phase = relationship("DiagnosticPhase")
    
    # Indexes and unique constraint
    __table_args__ = (
        Index("idx_symptom_entries_symptom_id", "symptom_id"),
        Index("idx_symptom_entries_phase_id", "phase_id"),
    )
    
    def __repr__(self):
        return f"<SymptomEntry(id={self.id}, session_id={self.session_id}, symptom_id={self.symptom_id}, present={self.present})>"
