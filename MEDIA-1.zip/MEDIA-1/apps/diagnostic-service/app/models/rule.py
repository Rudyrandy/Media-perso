"""
SQLAlchemy models for diagnostic rules and triggered rules.

This module defines the database models for rules (the logic that evaluates
symptoms) and triggered rules (rules that were activated during a session).
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class Rule(Base):
    """
    Model representing a diagnostic rule.
    
    Rules define the logic for evaluating symptoms and determining
    risk levels, scores, and recommendations.
    """
    __tablename__ = "rules"
    
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(80), nullable=False, unique=True, index=True)
    name = Column(String(200), nullable=False)
    rule_type = Column(String(30), nullable=False)
    priority = Column(Integer, default=100)
    message = Column(String(255), nullable=True)
    is_active = Column(Boolean, default=True)
    kind = Column(String(40), nullable=False)
    rule_operator = Column(String(10), nullable=False)
    value = Column(String(120), nullable=True)
    symptom_id = Column(Integer, ForeignKey("symptoms.id", ondelete="SET NULL"), nullable=True, index=True)
    measure_type = Column(String(30), nullable=True)
    measure_method = Column(String(30), nullable=True)
    created_at = Column(DateTime, nullable=True)
    
    # Relationships
    symptom = relationship("Symptom", back_populates="rules")
    triggered_rules = relationship("TriggeredRule", back_populates="rule", cascade="all, delete-orphan")
    
    # Indexes
    __table_args__ = (
        Index("idx_rules_symptom_id", "symptom_id"),
    )
    
    def __repr__(self):
        return f"<Rule(id={self.id}, code='{self.code}', name='{self.name}', rule_type='{self.rule_type}')>"


class TriggeredRule(Base):
    """
    Model representing a rule that was triggered during a diagnostic session.
    
    When a rule's conditions are met during a diagnostic evaluation,
    a triggered rule record is created to track which rules influenced the result.
    """
    __tablename__ = "triggered_rules"
    
    id = Column(Integer, primary_key=True, index=True)
    result_id = Column(Integer, ForeignKey("diagnostic_results.id", ondelete="CASCADE"), nullable=False, index=True)
    rule_id = Column(Integer, ForeignKey("rules.id", ondelete="CASCADE"), nullable=False, index=True)
    reason = Column(String(255), nullable=True)
    created_at = Column(DateTime, nullable=True)
    
    # Relationships
    result = relationship("DiagnosticResult", back_populates="triggered_rules")
    rule = relationship("Rule", back_populates="triggered_rules")
    
    # Indexes
    __table_args__ = (
        Index("idx_triggered_rules_result_id", "result_id"),
        Index("idx_triggered_rules_rule_id", "rule_id"),
    )
    
    def __repr__(self):
        return f"<TriggeredRule(id={self.id}, result_id={self.result_id}, rule_id={self.rule_id})>"
