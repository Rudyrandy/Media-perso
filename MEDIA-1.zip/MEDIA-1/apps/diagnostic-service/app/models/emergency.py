"""
SQLAlchemy models for emergency configuration and alert logs.

This module defines the database models for emergency settings
and logs of emergency alerts triggered during diagnostic sessions.
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class EmergencyConfig(Base):
    """
    Model representing emergency configuration settings.
    
    Emergency config defines emergency phone numbers for different
    geographic scopes (global, country, or region).
    """
    __tablename__ = "emergency_config"
    
    id = Column(Integer, primary_key=True, index=True)
    scope = Column(String(30), nullable=False, default="global")
    country_code = Column(String(10), nullable=True)
    region = Column(String(80), nullable=True)
    emergency_number = Column(String(30), nullable=False)
    is_active = Column(Boolean, default=True)
    updated_at = Column(DateTime, nullable=True)
    
    def __repr__(self):
        return f"<EmergencyConfig(id={self.id}, scope='{self.scope}', emergency_number='{self.emergency_number}')>"


class EmergencyAlertLog(Base):
    """
    Model representing an emergency alert triggered during a diagnostic session.
    
    When a diagnostic session detects an urgent risk level, an emergency alert
    is logged to track when and how the emergency was handled.
    """
    __tablename__ = "emergency_alert_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(Integer, ForeignKey("diagnostic_sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    detected = Column(Boolean, nullable=False, default=True)
    message = Column(String(255), nullable=True)
    emergency_number = Column(String(30), nullable=True)
    resolved_country = Column(String(10), nullable=True)
    created_at = Column(DateTime, nullable=True)
    
    # Relationships
    session = relationship("DiagnosticSession", back_populates="emergency_alerts")
    
    # Indexes
    __table_args__ = (
        Index("idx_emergency_alert_logs_session_id", "session_id"),
    )
    
    def __repr__(self):
        return f"<EmergencyAlertLog(id={self.id}, session_id={self.session_id}, detected={self.detected})>"
