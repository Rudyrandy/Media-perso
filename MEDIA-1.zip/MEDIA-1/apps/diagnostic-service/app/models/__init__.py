"""
SQLAlchemy models package for the diagnostic service.

This package contains all database models for the diagnostic microservice.
Models are organized by domain:
- diagnostic: DiagnosticPhase, DiagnosticSession
- symptom: Symptom, SymptomEntry
- rule: Rule, TriggeredRule
- result: DiagnosticResult
- emergency: EmergencyConfig, EmergencyAlertLog
"""

from app.models.diagnostic import DiagnosticPhase, DiagnosticSession
from app.models.symptom import Symptom, SymptomEntry
from app.models.rule import Rule, TriggeredRule
from app.models.result import DiagnosticResult
from app.models.emergency import EmergencyConfig, EmergencyAlertLog

__all__ = [
    # Diagnostic models
    "DiagnosticPhase",
    "DiagnosticSession",
    # Symptom models
    "Symptom",
    "SymptomEntry",
    # Rule models
    "Rule",
    "TriggeredRule",
    # Result models
    "DiagnosticResult",
    # Emergency models
    "EmergencyConfig",
    "EmergencyAlertLog",
]
