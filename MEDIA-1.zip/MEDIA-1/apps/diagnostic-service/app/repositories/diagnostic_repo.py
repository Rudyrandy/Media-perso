"""
Repository for diagnostic sessions.

This module handles database operations for diagnostic sessions using MongoDB with Motor.
"""

from datetime import datetime
from typing import Optional
from bson import ObjectId

from app.core.database import get_mongo_client
from app.core.config import settings


async def create_session(patient_profile_id: str) -> Optional[dict]:
    """
    Create a new diagnostic session.
    
    Args:
        patient_profile_id: ID of the patient profile starting the session (ObjectId as string)
        
    Returns:
        dict | None: The created session document if successful, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        session_data = {
            "patientId": ObjectId(patient_profile_id),
            "status": "started",
            "createdAt": datetime.utcnow(),
            "updatedAt": datetime.utcnow()
        }
        
        result = await db.diagnostic_session.insert_one(session_data)
        if result.inserted_id:
            session = await db.diagnostic_session.find_one({"_id": result.inserted_id})
            if session:
                session["id"] = str(session["_id"])
                session["patientId"] = str(session["patientId"])
            return session
        return None
    except:
        return None


async def get_session_by_id(session_id: str) -> Optional[dict]:
    """
    Get a diagnostic session by ID.
    
    Args:
        session_id: ID of the session to retrieve (ObjectId as string)
        
    Returns:
        dict | None: The session document if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        session = await db.diagnostic_session.find_one({"_id": ObjectId(session_id)})
        if session:
            session["id"] = str(session["_id"])
            if session.get("patientId"):
                session["patientId"] = str(session["patientId"])
            if session.get("userId"):
                session["userId"] = str(session["userId"])
        return session
    except:
        return None


async def get_active_phases() -> list[dict]:
    """
    Get all active diagnostic phases ordered by order_no.
    
    Returns:
        list[dict]: List of active phase documents sorted by order_no
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    phases = await db.diagnostic_phases.find({"active": True}).sort("order", 1).to_list(None)
    for phase in phases:
        phase["id"] = str(phase["_id"])
    return phases


async def get_phase_by_id(phase_id: str) -> Optional[dict]:
    """
    Get a diagnostic phase by ID.
    
    Args:
        phase_id: ID of the phase to retrieve (ObjectId as string)
        
    Returns:
        dict | None: The phase document if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        phase = await db.diagnostic_phases.find_one({"_id": ObjectId(phase_id)})
        if phase:
            phase["id"] = str(phase["_id"])
        return phase
    except:
        return None


async def update_session_to_completed(session_id: str) -> Optional[dict]:
    """
    Update a diagnostic session to completed status.
    
    This function sets the session status to 'completed', sets completedAt and updatedAt
    to the current timestamp, and returns the updated session.
    
    Args:
        session_id: ID of the diagnostic session to update (ObjectId as string)
        
    Returns:
        dict | None: The updated session document if found, None otherwise
        
    Note:
        Once a session is completed, it should not accept further modifications.
        Other endpoints should respect this functional lock.
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        result = await db.diagnostic_session.update_one(
            {"_id": ObjectId(session_id)},
            {
                "$set": {
                    "status": "completed",
                    "completedAt": datetime.utcnow(),
                    "updatedAt": datetime.utcnow()
                }
            }
        )
        if result.modified_count > 0:
            session = await db.diagnostic_session.find_one({"_id": ObjectId(session_id)})
            session["id"] = str(session["_id"])
            if session.get("patientId"):
                session["patientId"] = str(session["patientId"])
            if session.get("userId"):
                session["userId"] = str(session["userId"])
            return session
        return None
    except:
        return None


async def update_session_status(session_id: str, status: str) -> Optional[dict]:
    """
    Update a diagnostic session status.
    
    Args:
        session_id: ID of the diagnostic session to update (ObjectId as string)
        status: New status value
        
    Returns:
        dict | None: The updated session document if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        result = await db.diagnostic_session.update_one(
            {"_id": ObjectId(session_id)},
            {
                "$set": {
                    "status": status,
                    "updatedAt": datetime.utcnow()
                }
            }
        )
        if result.modified_count > 0:
            session = await db.diagnostic_session.find_one({"_id": ObjectId(session_id)})
            session["id"] = str(session["_id"])
            if session.get("patientId"):
                session["patientId"] = str(session["patientId"])
            if session.get("userId"):
                session["userId"] = str(session["userId"])
            return session
        return None
    except:
        return None


async def save_diagnostic_result(patient_id: str, result_data: dict) -> Optional[dict]:
    """
    Save a diagnostic evaluation result to the results collection.
    
    Args:
        patient_id: ID of the patient (ObjectId as string)
        result_data: Dictionary containing the diagnostic result data
        
    Returns:
        dict | None: The saved document if successful, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        document = {
            "patientId": ObjectId(patient_id),
            **result_data,
            "createdAt": datetime.utcnow(),
            "updatedAt": datetime.utcnow()
        }
        
        result = await db.results.insert_one(document)
        if result.inserted_id:
            saved = await db.results.find_one({"_id": result.inserted_id})
            if saved:
                saved["id"] = str(saved["_id"])
                saved["patientId"] = str(saved["patientId"])
                if "userId" in saved and saved["userId"]:
                    saved["userId"] = str(saved["userId"])
                if "doctorId" in saved and saved["doctorId"]:
                    saved["doctorId"] = str(saved["doctorId"])
            return saved
        return None
    except Exception as e:
        print(f"Error saving diagnostic result: {e}")
        return None
