"""
Repository for symptoms.

This module handles database operations for symptoms using MongoDB with Motor.
Entries are now embedded in the diagnostic_phase document.
"""

from typing import List, Optional
from bson import ObjectId
from datetime import datetime

from app.core.database import get_mongo_client
from app.core.config import settings


async def get_active_symptoms_by_phase(phase_id: str) -> List[dict]:
    """
    Get all active symptoms for a given phase by phase ID.
    
    Args:
        phase_id: ID of the phase to get symptoms for (ObjectId as string)
        
    Returns:
        List[dict]: List of active symptom documents for the phase
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        # First get the phase to find its code
        phase = await db.diagnostic_phases.find_one({"_id": ObjectId(phase_id)})
        if not phase:
            return []
        
        # Query symptoms by phaseCode
        symptoms = await db.symptoms.find(
            {"phaseCode": phase.get("code"), "active": True}
        ).sort("order", 1).to_list(None)
        for symptom in symptoms:
            symptom["id"] = str(symptom["_id"])
        return symptoms
    except:
        return []


async def get_symptom_by_id(symptom_id: str) -> Optional[dict]:
    """
    Get a symptom by ID.
    
    Args:
        symptom_id: ID of the symptom to retrieve (ObjectId as string)
        
    Returns:
        dict | None: The symptom document if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        symptom = await db.symptoms.find_one({"_id": ObjectId(symptom_id)})
        if symptom:
            symptom["id"] = str(symptom["_id"])
        return symptom
    except:
        return None


async def get_symptoms_by_ids(symptom_ids: List[str]) -> List[dict]:
    """
    Get symptoms by a list of IDs.
    
    Args:
        symptom_ids: List of symptom IDs to retrieve (ObjectId as strings)
        
    Returns:
        List[dict]: List of symptom documents matching the IDs
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        object_ids = [ObjectId(sid) for sid in symptom_ids]
        symptoms = await db.symptoms.find({"_id": {"$in": object_ids}}).to_list(None)
        for symptom in symptoms:
            symptom["id"] = str(symptom["_id"])
        return symptoms
    except:
        return []


async def add_entry_to_session(session_id: str, entry_data: dict) -> Optional[dict]:
    """
    Add an entry to the session's entries array.
    
    Args:
        session_id: ID of the diagnostic session (ObjectId as string)
        entry_data: Dictionary containing the entry data
        
    Returns:
        dict | None: The updated session document if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        result = await db.diagnostic_session.update_one(
            {"_id": ObjectId(session_id)},
            {
                "$push": {"entries": entry_data},
                "$set": {"updatedAt": datetime.utcnow()}
            }
        )
        if result.modified_count > 0:
            session = await db.diagnostic_session.find_one({"_id": ObjectId(session_id)})
            session["id"] = str(session["_id"])
            return session
        return None
    except:
        return None


async def update_entry_in_session(session_id: str, entry_index: int, entry_data: dict) -> Optional[dict]:
    """
    Update an entry in the session's entries array.
    
    Args:
        session_id: ID of the diagnostic session (ObjectId as string)
        entry_index: Index of the entry to update
        entry_data: Dictionary containing the fields to update
        
    Returns:
        dict | None: The updated session document if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        # Build the update path dynamically
        update_fields = {}
        for key, value in entry_data.items():
            update_fields[f"entries.{entry_index}.{key}"] = value
        
        result = await db.diagnostic_session.update_one(
            {"_id": ObjectId(session_id)},
            {
                "$set": {**update_fields, "updatedAt": datetime.utcnow()}
            }
        )
        if result.modified_count > 0:
            session = await db.diagnostic_session.find_one({"_id": ObjectId(session_id)})
            session["id"] = str(session["_id"])
            return session
        return None
    except:
        return None


async def save_session_symptoms_to_collection(session_id: str, patient_id: str, symptoms: list[dict]) -> Optional[dict]:
    """
    Save session symptoms to the diagnostic_session_symptoms collection.
    
    This creates or updates a document in the diagnostic_session_symptoms collection
    with the session symptoms.
    
    Args:
        session_id: ID of the diagnostic session (ObjectId as string)
        patient_id: ID of the patient (ObjectId as string)
        symptoms: List of symptom entries
        
    Returns:
        dict | None: The saved document if successful, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        # Check if a document already exists for this session
        existing = await db.diagnostic_session_symptoms.find_one({"diagnosticSessionId": ObjectId(session_id)})
        
        document = {
            "diagnosticSessionId": ObjectId(session_id),
            "patientId": ObjectId(patient_id),
            "symptoms": symptoms,
            "updatedAt": datetime.utcnow()
        }
        
        if existing:
            # Update existing document
            result = await db.diagnostic_session_symptoms.update_one(
                {"diagnosticSessionId": ObjectId(session_id)},
                {"$set": document}
            )
            if result.modified_count > 0:
                updated = await db.diagnostic_session_symptoms.find_one({"diagnosticSessionId": ObjectId(session_id)})
                if updated:
                    updated["id"] = str(updated["_id"])
                    updated["diagnosticSessionId"] = str(updated["diagnosticSessionId"])
                    updated["patientId"] = str(updated["patientId"])
                    # Convert symptomIds to strings
                    for symptom in updated.get("symptoms", []):
                        if "symptomId" in symptom:
                            symptom["symptomId"] = str(symptom["symptomId"])
                return updated
        else:
            # Create new document
            document["createdAt"] = datetime.utcnow()
            result = await db.diagnostic_session_symptoms.insert_one(document)
            if result.inserted_id:
                saved = await db.diagnostic_session_symptoms.find_one({"_id": result.inserted_id})
                if saved:
                    saved["id"] = str(saved["_id"])
                    saved["diagnosticSessionId"] = str(saved["diagnosticSessionId"])
                    saved["patientId"] = str(saved["patientId"])
                    # Convert symptomIds to strings
                    for symptom in saved.get("symptoms", []):
                        if "symptomId" in symptom:
                            symptom["symptomId"] = str(symptom["symptomId"])
                return saved
        return None
    except Exception as e:
        print(f"Error saving session symptoms to collection: {e}")
        return None


async def get_session_symptoms_from_collection(session_id: str) -> Optional[dict]:
    """
    Get session symptoms from the diagnostic_session_symptoms collection.
    
    Args:
        session_id: ID of the diagnostic session (ObjectId as string)
        
    Returns:
        dict | None: The document with symptoms if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        document = await db.diagnostic_session_symptoms.find_one({"diagnosticSessionId": ObjectId(session_id)})
        if document:
            document["id"] = str(document["_id"])
            document["diagnosticSessionId"] = str(document["diagnosticSessionId"])
            document["patientId"] = str(document["patientId"])
            # Convert symptomIds to strings
            for symptom in document.get("symptoms", []):
                if "symptomId" in symptom:
                    symptom["symptomId"] = str(symptom["symptomId"])
        return document
    except Exception as e:
        print(f"Error getting session symptoms from collection: {e}")
        return None
