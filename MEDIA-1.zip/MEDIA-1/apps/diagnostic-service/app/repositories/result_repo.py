"""
Repository for diagnostic results.

This module handles database operations for diagnostic results using MongoDB with Motor.
"""

from datetime import datetime
from typing import Optional
from bson import ObjectId

from app.core.database import get_mongo_client
from app.core.config import settings


async def create_result(payload: dict) -> dict:
    """
    Create a new diagnostic result in MongoDB.
    
    Args:
        payload: Dictionary containing the result data
        
    Returns:
        dict: The created result document
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    payload["created_at"] = datetime.utcnow()
    result = await db.diagnostic_results.insert_one(payload)
    created_result = await db.diagnostic_results.find_one({"_id": result.inserted_id})
    created_result["id"] = str(created_result["_id"])
    return created_result


async def get_latest_result_by_session_id(session_id: str) -> Optional[dict]:
    """
    Get the latest diagnostic result for a session.
    
    Args:
        session_id: ID of the diagnostic session (ObjectId as string)
        
    Returns:
        dict | None: The latest result document if found, None otherwise
    """
    client = get_mongo_client()
    db = client[settings.MONGO_DB_NAME]
    
    try:
        result = await db.diagnostic_results.find_one(
            {"session_id": session_id},
            sort=[("created_at", -1)]
        )
        if result:
            result["id"] = str(result["_id"])
        return result
    except:
        return None
