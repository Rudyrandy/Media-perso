"""
Main FastAPI application entry point.

This module initializes the FastAPI application and includes all API routers.
"""

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError

from app.api.v1 import routes
from app.core.config import settings
from app.core.database import connect_to_mongo, close_mongo_connection
from app.schemas.response import create_error_response

app = FastAPI(
    title="Diagnostic Service API",
    description="Microservice for medical diagnostic sessions",
    version="1.0.0"
)

# CORS middleware configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.backend_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include v1 API routes
app.include_router(routes.router, prefix="/api/v1")


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler to return standardized error responses."""
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=create_error_response(
            "Erreur interne du serveur",
            "INTERNAL_ERROR",
            str(exc)
        )
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Validation exception handler to return standardized error responses."""
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content=create_error_response(
            "Erreur de validation des données",
            "VALIDATION_ERROR",
            str(exc)
        )
    )


@app.on_event("startup")
async def startup_event():
    """Connect to MongoDB on application startup."""
    await connect_to_mongo()


@app.on_event("shutdown")
async def shutdown_event():
    """Close MongoDB connection on application shutdown."""
    await close_mongo_connection()


@app.get("/")
def root():
    """Root endpoint for health check."""
    return {"message": "Diagnostic Service API", "version": "1.0.0"}


@app.get("/health")
def health():
    """Health check endpoint."""
    return {"status": "healthy"}


@app.get("/test-mongo")
async def test_mongo():
    """Test MongoDB connection by pinging the database."""
    from app.core.database import get_mongo_client
    try:
        client = get_mongo_client()
        await client.admin.command('ping')
        return {"status": "MongoDB connection successful", "database": settings.MONGO_DB_NAME}
    except Exception as e:
        return {"status": "MongoDB connection failed", "error": str(e)}
