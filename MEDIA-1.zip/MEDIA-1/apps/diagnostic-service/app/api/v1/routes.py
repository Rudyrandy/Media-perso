"""
Main API router for v1 endpoints.

This module aggregates all API routers for the v1 API version.
"""

from fastapi import APIRouter

from app.api.v1 import diagnostic

router = APIRouter()

# Include diagnostic endpoints
router.include_router(diagnostic.router, prefix="/diagnostic", tags=["diagnostic"])
