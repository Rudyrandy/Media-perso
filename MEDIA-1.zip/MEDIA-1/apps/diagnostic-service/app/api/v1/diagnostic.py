"""
FastAPI routes for diagnostic session operations.

This module defines the API endpoints for managing diagnostic sessions using MongoDB.
"""

from fastapi import APIRouter, HTTPException

from app.schemas.diagnostic import DiagnosticSessionCreate, DiagnosticSessionResponse, DiagnosticPhaseResponse, DiagnosticResultResponse, ResultResponse
from app.schemas.symptom import SymptomResponse, SymptomEntryBulkCreate, SessionSymptomsResponse
from app.schemas.response import create_success_response, create_error_response
from app.services import diagnostic_service, symptom_service

router = APIRouter()


@router.post("/start")
async def start_diagnostic_session(
    session_data: DiagnosticSessionCreate
) -> dict:
    """
    Démarrer une nouvelle session de diagnostic.
    
    Ce endpoint crée une nouvelle session de diagnostic pour un patient donné.
    
    Args:
        session_data: Données de création de la session (patient_id requis)
        
    Returns:
        dict: Réponse standardisée avec la session créée
        
    Raises:
        HTTPException: 400 si la validation des données échoue
        HTTPException: 500 si une erreur inattendue survient
    """
    try:
        session = await diagnostic_service.start_diagnostic(session_data.patient_profile_id)
        return create_success_response("Session de diagnostic créée avec succès", session)
    except ValueError as e:
        return create_error_response("Erreur de validation", "VALIDATION_ERROR", str(e))
    except Exception as e:
        return create_error_response("Erreur interne du serveur", "INTERNAL_ERROR", str(e))


@router.get("/phases")
async def get_phases() -> dict:
    """
    Obtenir toutes les phases de diagnostic actives.
    
    Ce endpoint retourne toutes les phases de diagnostic actives triées par ordre.
        
    Returns:
        dict: Réponse standardisée avec la liste des phases
        
    Raises:
        HTTPException: 500 si une erreur inattendue survient
    """
    try:
        phases = await diagnostic_service.list_active_phases()
        return create_success_response("Phases récupérées avec succès", phases)
    except Exception as e:
        return create_error_response("Erreur interne du serveur", "INTERNAL_ERROR", str(e))


@router.get("/phases/{phase_id}/symptoms")
async def get_phase_symptoms(
    phase_id: str
) -> dict:
    """
    Obtenir tous les symptômes actifs pour une phase spécifique par ID de phase.
    
    Ce endpoint retourne tous les symptômes actifs pour l'ID de phase donné.
    Il valide d'abord que la phase existe.
        
    Args:
        phase_id: ID de la phase (ObjectId en string)
        
    Returns:
        dict: Réponse standardisée avec la liste des symptômes
        
    Raises:
        HTTPException: 400 si phase_id est invalide
        HTTPException: 404 si la phase n'est pas trouvée
        HTTPException: 500 si une erreur inattendue survient
    """
    try:
        symptoms = await symptom_service.list_symptoms_by_phase(phase_id)
        return create_success_response("Symptômes récupérés avec succès", symptoms)
    except ValueError as e:
        return create_error_response("Erreur de validation", "VALIDATION_ERROR", str(e))
    except Exception as e:
        return create_error_response("Erreur interne du serveur", "INTERNAL_ERROR", str(e))


@router.post("/{session_id}/symptoms")
async def save_session_symptoms(
    session_id: str,
    entries_data: SymptomEntryBulkCreate
) -> dict:
    """
    Enregistrer les entrées de symptômes pour une session de diagnostic.
    
    Ce endpoint crée ou met à jour les entrées de symptômes pour une session donnée
    dans la collection diagnostic_session_symptoms.
    
    Args:
        session_id: ID de la session de diagnostic (ObjectId en string)
        entries_data: Données de création en bloc contenant les entrées de symptômes
        
    Returns:
        dict: Réponse standardisée avec le document enregistré
        
    Raises:
        HTTPException: 400 si session_id est invalide ou si la validation des données échoue
        HTTPException: 404 si la session n'est pas trouvée
        HTTPException: 500 si une erreur inattendue survient
    """
    try:
        result = await symptom_service.save_session_symptoms(session_id, entries_data.entries)
        return create_success_response("Symptômes enregistrés avec succès", result)
    except ValueError as e:
        return create_error_response("Erreur de validation", "VALIDATION_ERROR", str(e))
    except Exception as e:
        return create_error_response("Erreur interne du serveur", "INTERNAL_ERROR", str(e))


@router.post("/{session_id}/evaluate")
async def evaluate_diagnostic_session(
    session_id: str
) -> dict:
    """
    Évaluer une session de diagnostic en utilisant le moteur de règles.
    
    Ce endpoint analyse les symptômes soumis et génère une évaluation diagnostique
    enregistrée dans la collection results.
    
    Args:
        session_id: ID de la session de diagnostic (ObjectId en string)
        
    Returns:
        dict: Réponse standardisée avec le résultat de l'évaluation
        
    Raises:
        HTTPException: 400 si session_id est invalide
        HTTPException: 404 si la session n'est pas trouvée
        HTTPException: 500 si une erreur inattendue survient
    """
    try:
        result = await diagnostic_service.evaluate_diagnostic(session_id)
        return create_success_response("Évaluation diagnostique effectuée avec succès", result)
    except ValueError as e:
        return create_error_response("Erreur de validation", "VALIDATION_ERROR", str(e))
    except Exception as e:
        return create_error_response("Erreur interne du serveur", "INTERNAL_ERROR", str(e))


@router.post("/{session_id}/finish")
async def finish_diagnostic_session(
    session_id: str
) -> dict:
    """
    Terminer une session de diagnostic en la marquant comme complétée.
    
    Ce endpoint vérifie que la session existe, n'est pas déjà complétée,
    puis met à jour son statut à 'completed'.
        
    Args:
        session_id: ID de la session de diagnostic (ObjectId en string)
        
    Returns:
        dict: Réponse standardisée avec la session mise à jour
        
    Raises:
        HTTPException: 400 si session_id est invalide
        HTTPException: 404 si la session n'est pas trouvée
        HTTPException: 500 si une erreur inattendue survient
    """
    try:
        session = await diagnostic_service.finish_diagnostic(session_id)
        return create_success_response("Session de diagnostic terminée avec succès", session)
    except ValueError as e:
        return create_error_response("Erreur de validation", "VALIDATION_ERROR", str(e))
    except Exception as e:
        return create_error_response("Erreur interne du serveur", "INTERNAL_ERROR", str(e))


@router.get("/{session_id}/symptoms")
async def get_session_symptoms(
    session_id: str
) -> dict:
    """
    Obtenir toutes les entrées de symptômes soumises pour une session de diagnostic.
    
    Ce endpoint permet au patient de revoir ses symptômes soumis
    depuis la collection diagnostic_session_symptoms.
    
    Args:
        session_id: ID de la session de diagnostic (ObjectId en string)
        
    Returns:
        dict: Réponse standardisée avec les symptômes de la session
        
    Raises:
        HTTPException: 400 si session_id est invalide
        HTTPException: 404 si la session n'est pas trouvée
        HTTPException: 500 si une erreur inattendue survient
    """
    try:
        result = await symptom_service.get_session_symptoms(session_id)
        if not result:
            return create_error_response("Symptômes non trouvés", "NOT_FOUND", "Session symptoms not found")
        return create_success_response("Symptômes récupérés avec succès", result)
    except ValueError as e:
        return create_error_response("Erreur de validation", "VALIDATION_ERROR", str(e))
    except Exception as e:
        return create_error_response("Erreur interne du serveur", "INTERNAL_ERROR", str(e))

" toujours "