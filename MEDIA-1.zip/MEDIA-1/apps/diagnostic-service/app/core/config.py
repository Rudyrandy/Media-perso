"""
Configuration module for environment variables and application settings.

This module loads environment variables and provides a centralized configuration
for the application, including database connection parameters.
"""

import os
from typing import Optional, Literal
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator, ValidationError
from functools import lru_cache


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.
    
    All sensitive values must be provided via environment variables.
    Hardcoded credentials are strictly prohibited for security reasons.
    
    Attributes:
        ENV: Application environment (dev or prod)
        DB_HOST: Database host address (required)
        DB_PORT: Database port number (required)
        DB_NAME: Database name (required)
        DB_USER: Database username (required)
        DB_PASSWORD: Database password (required)
        DB_ECHO: Enable SQLAlchemy query logging (auto-enabled in dev mode)
    """
    
    # Application environment
    ENV: Literal["dev", "prod"] = Field(
        default="prod",
        description="Application environment: 'dev' or 'prod'"
    )
    
    # MySQL configuration (optional, for legacy support)
    DB_HOST: Optional[str] = Field(
        default=None,
        description="MySQL database host address (optional, deprecated)"
    )
    DB_PORT: int = Field(
        default=3306,
        description="MySQL database port number (optional, deprecated)"
    )
    DB_NAME: Optional[str] = Field(
        default=None,
        description="MySQL database name (optional, deprecated)"
    )
    DB_USER: Optional[str] = Field(
        default=None,
        description="MySQL database username (optional, deprecated)"
    )
    DB_PASSWORD: Optional[str] = Field(
        default=None,
        description="MySQL database password (optional, deprecated)"
    )
    
    # Debug mode for SQLAlchemy (can be overridden, defaults based on ENV)
    DB_ECHO: Optional[bool] = Field(
        default=None,
        description="Enable SQLAlchemy query logging (overrides ENV-based default)"
    )
    
    # CORS configuration
    BACKEND_CORS_ORIGINS: str = Field(
        default="",
        description="Comma-separated list of allowed CORS origins for frontend"
    )
    
    # MongoDB configuration
    MONGO_URI: str = Field(
        ...,
        description="MongoDB connection URI (e.g., mongodb://localhost:27017 or MongoDB Atlas URI)"
    )
    MONGO_DB_NAME: str = Field(
        ...,
        description="MongoDB database name"
    )
    
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"
    )
    
    @field_validator("MONGO_URI", "MONGO_DB_NAME")
    @classmethod
    def validate_non_empty(cls, v: str, info) -> str:
        """
        Validate that required string fields are not empty.
        
        Args:
            v: Field value to validate
            info: Field validation context
            
        Returns:
            str: Validated field value
            
        Raises:
            ValueError: If field is empty or only whitespace
        """
        if not v or not v.strip():
            raise ValueError(
                f"{info.field_name} cannot be empty. "
                f"Please set the {info.field_name} environment variable."
            )
        return v
    
    @field_validator("DB_PORT")
    @classmethod
    def validate_port(cls, v: int) -> int:
        """
        Validate that DB_PORT is a valid port number.
        
        Args:
            v: Port number to validate
            
        Returns:
            int: Validated port number
            
        Raises:
            ValueError: If port is out of valid range
        """
        if not 1 <= v <= 65535:
            raise ValueError(
                f"DB_PORT must be between 1 and 65535, got {v}"
            )
        return v
    
    @property
    def is_dev(self) -> bool:
        """
        Check if application is running in development mode.
        
        Returns:
            bool: True if ENV is 'dev', False otherwise
        """
        return self.ENV == "dev"
    
    @property
    def is_prod(self) -> bool:
        """
        Check if application is running in production mode.
        
        Returns:
            bool: True if ENV is 'prod', False otherwise
        """
        return self.ENV == "prod"
    
    @property
    def should_echo_sql(self) -> bool:
        """
        Determine if SQL query logging should be enabled.
        
        Returns:
            bool: True if in dev mode or DB_ECHO is explicitly True
        """
        if self.DB_ECHO is not None:
            return self.DB_ECHO
        return self.is_dev
    
    @property
    def database_url(self) -> str:
        """
        Construct the database connection URL.
        
        Returns:
            str: SQLAlchemy-compatible database URL with pymysql driver
        """
        return (
            f"mysql+pymysql://{self.DB_USER}:{self.DB_PASSWORD}"
            f"@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"
            f"?charset=utf8mb4"
        )
    
    @property
    def backend_cors_origins(self) -> list[str]:
        """
        Parse the comma-separated CORS origins into a list.
        
        Returns:
            list[str]: List of allowed CORS origins
        """
        if self.BACKEND_CORS_ORIGINS:
            return [origin.strip() for origin in self.BACKEND_CORS_ORIGINS.split(",")]
        return []


@lru_cache()
def get_settings() -> Settings:
    """
    Get cached application settings.
    
    This function uses lru_cache to ensure settings are loaded only once
    and reused throughout the application lifecycle.
    
    Returns:
        Settings: Application settings instance
        
    Raises:
        ValidationError: If required environment variables are missing or invalid
    """
    try:
        return Settings()
    except ValidationError as e:
        raise ValueError(
            "Configuration error: Missing or invalid environment variables.\n"
            f"Details: {e}\n"
            "Please ensure all required environment variables are set in your .env file."
        ) from e


# Export settings instance for direct import
settings = get_settings()
