"""
Database configuration module for MongoDB using Motor.

This module provides MongoDB async client setup, database connection,
and dependency injection for FastAPI endpoints.
"""

from motor.motor_asyncio import AsyncIOMotorClient
from typing import AsyncGenerator
from app.core.config import settings


# Global MongoDB client
mongo_client: AsyncIOMotorClient = None


# Compatibility: Base class for SQLAlchemy models (deprecated, will be removed after full migration)
# This is kept temporarily to avoid import errors during the migration period
Base = object


async def connect_to_mongo() -> None:
    """
    Connect to MongoDB using Motor async client.
    
    This function establishes a connection to MongoDB and stores the client
    globally for reuse across the application.
    """
    global mongo_client
    mongo_client = AsyncIOMotorClient(settings.MONGO_URI)
    # Test the connection
    await mongo_client.admin.command('ping')
    print("Connected to MongoDB successfully")


async def close_mongo_connection() -> None:
    """
    Close the MongoDB connection.
    
    This function should be called during application shutdown
    to properly close the MongoDB connection.
    """
    global mongo_client
    if mongo_client:
        mongo_client.close()
        print("Closed MongoDB connection")


async def get_db() -> AsyncGenerator:
    """
    Dependency function for FastAPI to provide MongoDB database.
    
    This function yields the MongoDB database instance for use in endpoints.
    
    Yields:
        Motor database instance
        
    Example:
        @app.get("/users/")
        async def get_users(db = Depends(get_db)):
            return await db.users.find().to_list(None)
    """
    if mongo_client is None:
        await connect_to_mongo()
    yield mongo_client[settings.MONGO_DB_NAME]


def get_mongo_client() -> AsyncIOMotorClient:
    """
    Get the global MongoDB client.
    
    Returns:
        AsyncIOMotorClient: MongoDB client instance
        
    Raises:
        RuntimeError: If MongoDB client is not initialized
    """
    global mongo_client
    if mongo_client is None:
        raise RuntimeError("MongoDB client not initialized. Call connect_to_mongo() first.")
    return mongo_client
