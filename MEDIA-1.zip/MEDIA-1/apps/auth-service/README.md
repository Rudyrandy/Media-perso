# Auth Service

Microservice Node.js + MongoDB pour l'inscription, la connexion, la deconnexion et la verification de token des patients et medecins.

## Installation

```bash
npm install
npm run dev
```

## Variables

Copier `.env.example` vers `.env`, puis adapter `MONGO_URI` et `JWT_SECRET`.

## Routes

### POST /auth/register

Patient:

```json
{
  "phone": "+237600000000",
  "password": "secret123",
  "role": "patient",
  "preferredLanguage": "fr",
  "consent": true,
  "age": 30,
  "sex": "female",
  "countryCode": "CM",
  "region": "Centre"
}
```

Medecin:

```json
{
  "phone": "+237699000000",
  "password": "secret123",
  "role": "doctor",
  "preferredLanguage": "fr",
  "consent": true,
  "specialtyId": "cardiology",
  "licenseNumber": "LIC-123",
  "hospital": "Hopital General",
  "bio": "Cardiologue"
}
```

### POST /auth/login

```json
{
  "phone": "+237600000000",
  "password": "secret123"
}
```

### POST /auth/logout

Header:

```text
Authorization: Bearer <accessToken>
```

### GET /auth/verify

Header:

```text
Authorization: Bearer <accessToken>
```
