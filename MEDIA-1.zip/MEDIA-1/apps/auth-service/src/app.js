const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const authRoutes = require('./routes/authRoutes');
const { sendSuccess, sendError } = require('./utils/apiResponse');

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => {
  sendSuccess(res, 200, 'Service is healthy', {
    status: 'ok',
    service: 'auth-service'
  });
});

app.use('/auth', authRoutes);

app.use((req, res) => {
  sendError(res, 404, 'Route not found', 'ROUTE_404', 'The requested route does not exist');
});

app.use((err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal server error';
  const code = err.code || 'SERVER_ERROR';
  const details = err.details || message;

  if (err.name === 'JsonWebTokenError' || err.name === 'TokenExpiredError') {
    return sendError(res, 401, 'Invalid or expired token', 'AUTH_007', err.message);
  }

  sendError(res, statusCode, message, code, details);
});

module.exports = app;
