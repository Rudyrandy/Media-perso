const app = require('./app');
const connectDatabase = require('./config/database');
const env = require('./config/env');

const startServer = async () => {
  try {
    await connectDatabase();
    app.listen(env.port, () => {
      console.log(`auth-service listening on port ${env.port}`);
    });
  } catch (error) {
    console.error('Failed to start auth-service:', error.message);
    process.exit(1);
  }
};

startServer();
