const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const env = require('../config/env');

const hashToken = (token) => crypto.createHash('sha256').update(token).digest('hex');

const signAccessToken = (user) =>
  jwt.sign(
    {
      sub: user._id.toString(),
      role: user.role
    },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  );

const verifyAccessToken = (token) => jwt.verify(token, env.jwtSecret);

const getTokenExpirationDate = (token) => {
  const decoded = jwt.decode(token);

  if (!decoded || !decoded.exp) {
    return new Date(Date.now() + 60 * 60 * 1000);
  }

  return new Date(decoded.exp * 1000);
};

module.exports = {
  hashToken,
  signAccessToken,
  verifyAccessToken,
  getTokenExpirationDate
};
