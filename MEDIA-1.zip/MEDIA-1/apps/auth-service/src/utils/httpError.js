const createHttpError = (statusCode, message, code = 'ERROR', details = message) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  error.code = code;
  error.details = details;
  return error;
};

module.exports = createHttpError;
