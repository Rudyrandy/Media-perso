const AuthSession = require('../models/AuthSession');

const createSession = (data) => AuthSession.create(data);

const findActiveByAccessTokenHash = (accessTokenHash) =>
  AuthSession.findOne({
    accessTokenHash,
    revokedAt: null,
    expiresAt: { $gt: new Date() }
  });

const revokeByAccessTokenHash = (accessTokenHash) =>
  AuthSession.findOneAndUpdate(
    {
      accessTokenHash,
      revokedAt: null
    },
    {
      revokedAt: new Date()
    },
    { new: true }
  );

module.exports = {
  createSession,
  findActiveByAccessTokenHash,
  revokeByAccessTokenHash
};
