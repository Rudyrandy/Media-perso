const User = require('../models/user');
const PatientProfile = require('../models/PatientProfile');
const DoctorProfile = require('../models/DoctorProfile');

const findByPhone = (phone) => User.findOne({ phone });

const findById = (id) => User.findById(id);

const createUser = (data) => User.create(data);

const createPatientProfile = (data) => PatientProfile.create(data);

const createDoctorProfile = (data) => DoctorProfile.create(data);

module.exports = {
  findByPhone,
  findById,
  createUser,
  createPatientProfile,
  createDoctorProfile
};
