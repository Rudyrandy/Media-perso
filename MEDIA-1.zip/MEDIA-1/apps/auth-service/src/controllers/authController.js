const authService = require('../services/authService');
const { sendSuccess } = require('../utils/apiResponse');

const register = async (req, res, next) => {
  try {
    const user = await authService.register(req.body);
    sendSuccess(res, 201, 'User registered successfully', user);
  } catch (error) {
    next(error);
  }
};

const login = async (req, res, next) => {
  try {
    const result = await authService.login(req.body);
    sendSuccess(res, 200, 'Login successful', result);
  } catch (error) {
    next(error);
  }
};

const logout = async (req, res, next) => {
  try {
    const result = await authService.logout(req.headers.authorization);
    sendSuccess(res, 200, result.message, null);
  } catch (error) {
    next(error);
  }
};

const verify = async (req, res, next) => {
  try {
    const result = await authService.verify(req.headers.authorization);
    sendSuccess(res, 200, 'Token verified successfully', result);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  register,
  login,
  logout,
  verify
};
