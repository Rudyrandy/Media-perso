const bcrypt = require('bcryptjs');
const userRepository = require('../repositories/userRepository');
const sessionRepository = require('../repositories/sessionRepository');
const createHttpError = require('../utils/httpError');
const {
  hashToken,
  signAccessToken,
  verifyAccessToken,
  getTokenExpirationDate
} = require('../utils/token');

const publicUser = (user) => ({
  id: user._id,
  phone: user.phone,
  role: user.role,
  preferredLanguage: user.preferredLanguage,
  consent: user.consent
});

const getBearerToken = (authorizationHeader) => {
  if (!authorizationHeader || !authorizationHeader.startsWith('Bearer ')) {
    throw createHttpError(
      401,
      'Authorization token is required',
      'AUTH_002',
      'Use the Authorization header with Bearer token'
    );
  }

  return authorizationHeader.slice('Bearer '.length).trim();
};

const register = async (data) => {
  const { phone, password, role, preferredLanguage, consent } = data;

  if (!phone || !password || !role) {
    throw createHttpError(
      400,
      'phone, password and role are required',
      'VALIDATION_001',
      'Missing required registration fields'
    );
  }

  if (!['patient', 'doctor'].includes(role)) {
    throw createHttpError(
      400,
      'role must be patient or doctor',
      'VALIDATION_002',
      'Accepted roles are patient and doctor'
    );
  }

  const existingUser = await userRepository.findByPhone(phone);
  if (existingUser) {
    throw createHttpError(
      409,
      'Phone already registered',
      'AUTH_003',
      'This phone number is already linked to an account'
    );
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const user = await userRepository.createUser({
    phone,
    passwordHash,
    role,
    preferredLanguage: preferredLanguage || 'fr',
    consent: Boolean(consent)
  });

  if (role === 'patient') {
    await userRepository.createPatientProfile({
      userId: user._id,
      age: data.age,
      sex: data.sex,
      countryCode: data.countryCode,
      region: data.region
    });
  }

  if (role === 'doctor') {
    await userRepository.createDoctorProfile({
      userId: user._id,
      specialtyId: data.specialtyId,
      licenseNumber: data.licenseNumber,
      hospital: data.hospital,
      bio: data.bio,
      verified: false
    });
  }

  return publicUser(user);
};

const login = async ({ phone, password }) => {
  if (!phone || !password) {
    throw createHttpError(
      400,
      'phone and password are required',
      'VALIDATION_003',
      'Missing login credentials'
    );
  }

  const user = await userRepository.findByPhone(phone);
  if (!user) {
    throw createHttpError(
      401,
      'Invalid credentials',
      'AUTH_001',
      'Phone or password incorrect'
    );
  }

  const passwordIsValid = await bcrypt.compare(password, user.passwordHash);
  if (!passwordIsValid) {
    throw createHttpError(
      401,
      'Invalid credentials',
      'AUTH_001',
      'Phone or password incorrect'
    );
  }

  const accessToken = signAccessToken(user);
  await sessionRepository.createSession({
    userId: user._id,
    accessTokenHash: hashToken(accessToken),
    refreshTokenHash: null,
    expiresAt: getTokenExpirationDate(accessToken)
  });

  return {
    accessToken,
    tokenType: 'Bearer',
    expiresAt: getTokenExpirationDate(accessToken),
    user: publicUser(user)
  };
};

const logout = async (authorizationHeader) => {
  const token = getBearerToken(authorizationHeader);
  const revokedSession = await sessionRepository.revokeByAccessTokenHash(hashToken(token));

  if (!revokedSession) {
    throw createHttpError(
      401,
      'Session not found or already revoked',
      'AUTH_004',
      'The token session does not exist or was already revoked'
    );
  }

  return { message: 'Logged out successfully' };
};

const verify = async (authorizationHeader) => {
  const token = getBearerToken(authorizationHeader);
  const payload = verifyAccessToken(token);
  const session = await sessionRepository.findActiveByAccessTokenHash(hashToken(token));

  if (!session) {
    throw createHttpError(
      401,
      'Session expired or revoked',
      'AUTH_005',
      'The token session is expired, revoked or unknown'
    );
  }

  const user = await userRepository.findById(payload.sub);
  if (!user) {
    throw createHttpError(
      401,
      'User not found',
      'AUTH_006',
      'The token references a user that no longer exists'
    );
  }

  return {
    valid: true,
    user: publicUser(user)
  };
};

module.exports = {
  register,
  login,
  logout,
  verify
};
